export const SMS_PAGES = [
  {
    slug: "sms-onay",
    menuLabel: "SMS Onay",
    category: "SMS Onay Rehberleri",
    title: "SMS Onay Nedir? Nasıl Yapılır? | Onay Merkezi",
    description: "SMS onay nedir, neden istenir ve sanal numarayla nasıl tamamlanır? Güvenli, hızlı ve iade korumalı SMS onay sürecinin detaylarını öğrenin.",
    h1: "SMS Onay Nedir?",
    lead: "SMS onay, dijital platformların yeni hesap açılışında veya kritik güvenlik işlemlerinde kullanıcıya kısa mesajla tek kullanımlık doğrulama kodu (OTP) göndererek işlemi onaylaması sürecidir. Kişisel hattınızı paylaşmak istemediğiniz durumlarda bu doğrulama Onay Merkezi üzerinden alınan sanal numaralarla tamamlanabilir.",
    image: "/assets/images/seo-whatsapp-dogrulama.jpg",
    imageAlt: "SMS onay mekanizması ve tek kullanımlık doğrulama kodu süreci",
    imageCaption: "Platformların istediği OTP doğrulama kodunun web paneli üzerinden alınması.",
    sections: [
      {
        id: "sms-onay-amaci",
        h2: "Platformlar Neden SMS Onay İster?",
        paragraphs: [
          "WhatsApp, Telegram, Instagram, Google ve TikTok gibi büyük servisler otomatik bot hesapları engellemek ve spam trafiğini azaltmak için telefon doğrulaması uygular. Gönderilen 4 ila 6 haneli sayısal kod, hesabın gerçek bir iletişim hattıyla ilişkilendirildiğini kanıtlar."
        ]
      },
      {
        id: "sanal-numarayla-onay",
        h2: "Sanal Numara ile SMS Onay Nasıl İşler?",
        paragraphs: [
          "Onay Merkezi panelinde doğrulamak istediğiniz uygulamayı ve ülkeyi seçtiğinizde size anlık bir numara verilir. Uygulamaya bu numarayı yazıp kod istediğinizde, operatör geçidine ulaşan SMS doğrudan sipariş ekranınıza yansır. Kodu kopyalayıp uygulamaya yapıştırdığınız anda SMS onay işlemi tamamlanır."
        ]
      },
      {
        id: "desteklenen-platformlar",
        h2: "SMS Onay Hizmetinin Kapsadığı Servisler",
        paragraphs: [
          "Onay Merkezi'nde mesajlaşma, sosyal medya ve e-posta kategorilerinde geniş bir destek sunulur:"
        ],
        list: [
          "Mesajlaşma: WhatsApp (15 TL'den), WhatsApp Business (25 TL'den), Telegram (15 TL'den).",
          "Sosyal Medya: Instagram (20 TL'den), Facebook (20 TL'den), TikTok (25 TL'den).",
          "Topluluk & E-posta: Google/Gmail (18 TL'den), Discord (22 TL'den).",
          "Oyun Jetonları: PUBG, Free Fire, Valorant, Mobile Legends ve Steam cüzdan kodları ayrı kategoride sunulur."
        ]
      },
      {
        id: "otomatik-iade",
        h2: "SMS Gelmeyen Durumlarda Bakiye Koruması",
        paragraphs: [
          "SMS onay sistemlerinde her numara ilk denemede mesaj almayabilir. Bu olasılık göz önünde bulundurularak Onay Merkezi'nde 2 dakika sonrası iptal ve 10 dakika zaman aşımı sonrası tam iade mekanizması çalışır. Kod ulaşmayan hiçbir işlem için bakiyeniz eksilmez."
        ]
      }
    ],
    table: {
      title: "SMS Onay Süreci Temel Özellikleri",
      headers: ["Özellik", "Detay", "Kullanıcı Faydası"],
      rows: [
        ["İşlem Süresi", "10 dakika bekleme penceresi", "Kod gelene kadar anlık takip"],
        ["Otomatik Kontrol", "2 saniyede bir tarama", "Sayfa yenilemeden kod görünür"],
        ["İptal İmkanı", "2 dakika sonra aktif", "Beklemeden başka operatöre geçiş"],
        ["Ülke Çeşitliliği", "60+ ülke seçeneği", "Bütçe ve konuma uygun seçim"]
      ]
    },
    steps: {
      title: "4 Adımda SMS Onay Tamamlama",
      items: [
        { label: "Adım 1", title: "Servis Seçin", desc: "Doğrulama yapacağınız uygulamayı Onay Merkezi listesinden belirleyin." },
        { label: "Adım 2", title: "Ülke ve Operatör Seçin", desc: "Fiyat ve stok durumuna bakarak ülkenizi ve operatörünüzü seçin." },
        { label: "Adım 3", title: "Numarayı Girin", desc: "Teslim edilen numarayı uygulamanın telefon doğrulama kutusuna yazın." },
        { label: "Adım 4", title: "Kodu Onaylayın", desc: "Ekrana düşen OTP kodunu girerek hesap kurulumunu bitirin." }
      ]
    },
    faqs: [
      { q: "SMS onay işlemi ne kadar sürer?", a: "Numara seçimi ve kodun ekrana düşmesi çoğunlukla birkaç dakika sürer; maksimum bekleme penceresi 10 dakikadır." },
      { q: "SMS onay için telefonuma SIM kart takmam gerekir mi?", a: "Hayır. Gelen SMS web panelinizdeki sipariş ekranında metin olarak görüntülenir." },
      { q: "Kod gelmezse bakiyem silinir mi?", a: "Hayır. 2 dakika sonra iptal ettiğinizde ya da 10 dakikalık süre dolduğunda bakiye hesabınıza iade edilir." },
      { q: "Tek seferde birden fazla SMS kodu alabilir miyim?", a: "Standart aktivasyon numaraları tek doğrulama işlemi içindir; yeni doğrulama için yeni sipariş açılır." },
      { q: "SMS onay kodu güvenle saklanır mı?", a: "Evet, kendi hesabınıza ait geçmiş siparişleri alt menüdeki Siparişler sekmesinden görüntüleyebilirsiniz." }
    ],
    related: ["sms-onay-satin-al", "sms-onay-fiyatlari", "sms-dogrulama", "sms-kodu-gelmiyor", "sms-onay-nasil-calisir", "sms-onay-rehberi"]
  },
  {
    slug: "sms-onay-satin-al",
    menuLabel: "SMS Onay Satın Al",
    category: "SMS Onay Rehberleri",
    title: "SMS Onay Satın Alma Rehberi | Hızlı ve Şeffaf | Onay Merkezi",
    description: "SMS onay nasıl satın alınır? Bakiye yükleme, doğru servis ve operatör tercihi, kart veya IBAN ödeme adımlarıyla SMS onay satın alma rehberi.",
    h1: "SMS Onay Satın Alma Rehberi",
    lead: "SMS onay satın alma işlemi, dijital bir platformda hesap oluştururken ihtiyaç duyduğunuz tek seferlik telefon doğrulamasını pratik biçimde tamamlamanızı sağlar. Doğru sırayla ilerleyerek birkaç dakika içinde bakiye yükleyip onay kodunuzu alabilirsiniz.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "SMS onay satın alma ve bakiye yükleme adımları",
    imageCaption: "Minimum 100 TL bakiye yükleyerek tüm SMS onay servislerinden faydalanın.",
    sections: [
      {
        id: "uyelik-ve-bakiye",
        h2: "Üyelik ve Bakiye Yükleme Aşaması",
        paragraphs: [
          "SMS onay satın almak için önce Onay Merkezi'nde e-posta adresinizle bir kullanıcı hesabı oluşturmanız gerekir. Hesabınıza giriş yaptığınızda üst bölümde bakiye barı görünür. Bakiye Yükle sayfasında en düşük yükleme tutarı 100 TL'dir; 250 TL ve 500 TL seçeneklerinde sırasıyla %30 ve %35 indirim/bonus uygulanır."
        ]
      },
      {
        id: "platforma-gore-secim",
        h2: "Platforma Uygun Paket Belirleme",
        paragraphs: [
          "Satın alma yaparken hedef uygulamaya birebir karşılık gelen servisi seçmek kritik önem taşır:"
        ],
        list: [
          "Normal WhatsApp hesabı için 'WhatsApp', işletme hesabı için 'WhatsApp Business' seçilmelidir.",
          "Telegram doğrulaması için 'Telegram', Google servisleri için 'Google/Gmail' seçilmelidir.",
          "Sosyal medya hesaplarında Instagram, Facebook veya TikTok seçenekleri ayrı ayrı bulunur."
        ]
      },
      {
        id: "siparis-onayi",
        h2: "Satın Alma Butonu ve Anlık Bakiye Kontrolü",
        paragraphs: [
          "Ülke ve operatörü seçip 4. adıma geldiğinizde sistem güncel bakiyenizi anlık kontrol eder. Bakiyeniz yeterliyse 'Numarayı Satın Al' butonu aktif olur; yetersizse eksik tutar ekranda belirtilir ve tek tıkla Bakiye Yükle sayfasına yönlendirilirsiniz. Bakiye tamamlandığında sistem sizi kaldığınız adıma geri döndürür."
        ]
      },
      {
        id: "iptal-ve-tekrar",
        h2: "Kod Gelmeyen İşlemlerde İptal ve Yeni Deneme",
        paragraphs: [
          "Satın alma sonrası 2 dakika içinde kod gelmediyse iptal butonunu kullanıp bakiyeyi geri alarak hiç beklemeden başka bir operatörden yeni SMS onay satın alabilirsiniz."
        ]
      }
    ],
    table: {
      title: "SMS Onay Satın Alma Öncesi Kontrol Listesi",
      headers: ["Kontrol Maddesi", "Gereksinim", "Açıklama"],
      rows: [
        ["Hesap Oturumu", "Aktif üyelik", "Sipariş takibi ve iadeler için zorunludur"],
        ["Minimum Yükleme", "100 TL", "Kart veya IBAN Havale/EFT bildirimi ile"],
        ["Servis Eşleşmesi", "Doğru uygulama adı", "Platforma özel numara havuzu kullanılır"],
        ["Kullanım Penceresi", "10 dakika", "Numara bu süre boyunca SMS bekler"]
      ]
    },
    steps: {
      title: "SMS Onay Satın Alma Adımları",
      items: [
        { label: "Adım 1", title: "Kayıt ve Giriş Yapın", desc: "Kullanım Koşulları ve KVKK onayını vererek üyeliğinizi başlatın." },
        { label: "Adım 2", title: "Bakiye Ekleyin", desc: "IBAN veya kart sekmesinden en az 100 TL yükleyin." },
        { label: "Adım 3", title: "Servis, Ülke ve Operatör Seçin", desc: "İhtiyacınıza uygun ülke ve stoklu operatörü belirleyin." },
        { label: "Adım 4", title: "Numarayı Alıp Doğrulayın", desc: "Ekrana gelen numarayı uygulamaya girip SMS kodunu alın." }
      ]
    },
    faqs: [
      { q: "SMS onay satın aldıktan sonra ne kadar sürede numara gelir?", a: "Bakiyeniz yeterliyse satın alma butonuna bastığınız anda numara ekranınızda belirir." },
      { q: "Aldığım SMS onay kodunu sonradan tekrar görebilir miyim?", a: "Evet, alt menüdeki Siparişler bölümünden tüm geçmiş numaralarınızı ve gelen SMS kodlarını inceleyebilirsiniz." },
      { q: "IBAN ile bakiye yüklersem ne kadar beklerim?", a: "Havale/EFT sonrasında bildirim formunu doldurduğunuzda yönetici kontrolünün ardından bakiye hesabınıza tanımlanır." },
      { q: "Yanlış servisi seçersem ne yapmalıyım?", a: "Numarayı kullanmadıysanız 2 dakika sonra iptal edip bakiyenizi geri alabilir ve doğru servisi seçebilirsiniz." },
      { q: "Bakiye yüklerken bonus kampanyasından nasıl yararlanırım?", a: "250 TL ve üzeri yüklemelerde %30, 500 TL ve üzeri yüklemelerde %35 bonus oranı ödeme ekranında otomatik hesaplanır." }
    ],
    related: ["sms-onay", "sanal-numara-satin-al", "sanal-numara-odeme-yontemleri", "sanal-numara-iban-ile-odeme", "sms-onay-fiyatlari", "sms-onay-iade"]
  },
  {
    slug: "sms-onay-siteleri",
    menuLabel: "SMS Onay Siteleri",
    category: "SMS Onay Rehberleri",
    title: "SMS Onay Sitesi Seçerken Nelere Dikkat Edilmeli? | Onay Merkezi",
    description: "Güvenilir SMS onay siteleri nasıl ayırt edilir? İade politikası, şeffaf fiyat, ülke çeşitliliği, canlı destek ve gizlilik kriterlerini inceleyin.",
    h1: "SMS Onay Sitesi Seçerken Nelere Dikkat Edilmeli?",
    lead: "İnternette SMS onay hizmeti sunduğunu belirten çok sayıda platform bulunur; ancak hepsi aynı şeffaflığı ve iade disiplinini sunmaz. Bir SMS onay sitesini tercih etmeden önce iade kurallarını, gizlilik yaklaşımını ve operatör çeşitliliğini mutlaka değerlendirmelisiniz.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "Güvenilir SMS onay siteleri seçim kriterleri kontrol listesi",
    imageCaption: "Şeffaf fiyatlandırma, otomatik iade ve canlı destek erişimi temel ölçütlerdir.",
    sections: [
      {
        id: "temel-kriterler",
        h2: "Bir SMS Onay Sitesinde Aranması Gereken 5 Temel Kriter",
        paragraphs: [
          "Doğru platformu seçmek hem zaman kaybını önler hem de bakiyenizin boşa gitmesini engeller. Değerlendirme yaparken şu beş maddeye dikkat edebilirsiniz:"
        ],
        list: [
          "Kod Gelmezse İade Güvencesi: SMS ulaşmadığında bakiyenin kesilmemesi ve zaman aşımında otomatik iade edilmesi en önemli güvencedir.",
          "Şeffaf Fiyat ve Stok Gösterimi: Ülke ve operatör seçerken ne kadar ödeyeceğinizi ve stok durumunu önceden görebilmelisiniz.",
          "Çoklu Operatör Alternatifi: Tek bir operatöre bağlı kalmak yerine, yanıt geciktiğinde başka operatöre geçebilme imkanı olmalıdır.",
          "Ulaşılabilir Müşteri Desteği: Ödeme bildirimi veya sipariş sorunu yaşadığınızda canlı sohbet ve e-posta desteği bulunmalıdır.",
          "Yasal Bilgilendirme ve KVKK: Gizlilik Politikası, Kullanım Koşulları ve KVKK metinlerinin açıkça sunulması gerekir."
        ]
      },
      {
        id: "ucretsiz-tuzaklar",
        h2: "Ücretsiz vs Ücretli SMS Onay Siteleri",
        paragraphs: [
          "Aramalarda çıkan ücretsiz SMS siteleri reklam geliri için aynı numaraları herkese gösterir. Hem o numaralar popüler platformlarda engellenmiştir hem de gelen doğrulama kodunu başka biri anlık olarak görebilir. Güvenli ve özel bir işlem için her zaman üye paneli üzerinden numara tahsis eden sistemler tercih edilmelidir."
        ]
      },
      {
        id: "gercekci-olmayan-vaatler",
        h2: "Abartılı Vaatlere Karşı Dikkatli Olun",
        paragraphs: [
          "Hiçbir SMS onay sitesi her ülkenin ve her platformun %100 kesin kod göndereceğini iddia edemez; çünkü WhatsApp veya Instagram gibi uygulamalar kendi taraflarında anlık filtreler uygulayabilir. Önemli olan, kod gelmediğinde kullanıcının mağdur edilmeden bakiyesinin iade edilmesidir."
        ]
      },
      {
        id: "onay-merkezi-yaklasimi",
        h2: "Onay Merkezi'nin Şeffaf İşleyiş Yapısı",
        paragraphs: [
          "Onay Merkezi panelinde 60'tan fazla ülke, her ülke altında birden fazla operatör, 2 dakika sonrası iptal butonu, 10 dakika zaman aşımı iadesi, Canlı Destek penceresi ve IBAN/Kart ödeme seçenekleri tek çatı altında sunulur."
        ]
      }
    ],
    table: {
      title: "SMS Onay Platformu Değerlendirme Matrisi",
      headers: ["Kriter", "Olması Gereken Standart", "Riskli İşaretler"],
      rows: [
        ["İade Politikası", "Kod gelmezse otomatik bakiye iadesi", "'İade yok' veya belirsiz kurallar"],
        ["Numara Paylaşımı", "Sipariş süresince kişiye özel tahsis", "Herkese açık ortak gelen kutusu"],
        ["Fiyat Şeffaflığı", "İşlem öncesi net TL tutarı", "Gizli ek kesintiler"],
        ["İletişim", "Canlı destek ve destek@ e-postası", "Hiçbir iletişim bilgisi olmaması"]
      ]
    },
    steps: {
      title: "Doğru SMS Onay Sitesini Test Etme Adımları",
      items: [
        { label: "Adım 1", title: "Yasal Sayfaları İnceleyin", desc: "Gizlilik Politikası, Kullanım Koşulları ve KVKK metinlerinin varlığını kontrol edin." },
        { label: "Adım 2", title: "Ülke ve Fiyatları Karşılaştırın", desc: "Aradığınız servis ve ülkenin güncel fiyatını önceden görün." },
        { label: "Adım 3", title: "İptal Süresini Öğrenin", desc: "Kod gelmediğinde kaç dakika sonra iptal ve iade alabildiğinize bakın." },
        { label: "Adım 4", title: "Destek Kanalını Test Edin", desc: "Büyük tutarlar yüklemeden önce destek ekibinin erişilebilirliğini kontrol edin." }
      ]
    },
    faqs: [
      { q: "En iyi SMS onay sitesi nasıl anlaşılır?", a: "Kişisel verilere saygılı, kod gelmediğinde bakiye iadesi yapan, şeffaf fiyat gösteren ve aktif destek sunan platformlar güvenle kullanılabilir." },
      { q: "SMS onay sitelerinde kart bilgisi vermek zorunlu mu?", a: "Hayır. Onay Merkezi'nde dilerseniz kart yerine IBAN ile Havale/EFT bildirimi yöntemini kullanarak bakiye yükleyebilirsiniz." },
      { q: "Aynı sitede farklı uygulamalar için onay alabilir miyim?", a: "Evet. WhatsApp, Telegram, Instagram, Google/Gmail, Facebook, TikTok ve Discord tek panelde yer alır." },
      { q: "Bazı siteler neden %100 başarı garantisi yazar?", a: "Platformların anti-spam filtreleri sürekli değiştiği için hiçbir üçüncü taraf %100 garanti veremez; önemli olan başarısız işlemde paranızın iade edilmesidir." },
      { q: "Onay Merkezi'nde destek ekibine nasıl ulaşılır?", a: "Sayfanın sağ alt köşesindeki Canlı Destek butonunu veya destek@onaymerkezi.org e-posta adresini kullanabilirsiniz." }
    ],
    related: ["onay-merkezi-guvenilir-mi", "sanal-numara-guvenilir-mi", "sms-onay-iade", "sms-onay-guvenligi", "numara-alirken-dikkat-edilmesi-gerekenler", "sms-onay"]
  },
  {
    slug: "sms-onay-fiyatlari",
    menuLabel: "SMS Onay Fiyatları",
    category: "SMS Onay Rehberleri",
    title: "SMS Onay Fiyatları | Platform ve Ülke Tarifeleri | Onay Merkezi",
    description: "SMS onay fiyatları ne kadar? WhatsApp, Telegram, Gmail, Instagram, Facebook, Discord ve TikTok için 15 TL'den başlayan güncel fiyatlar.",
    h1: "SMS Onay Fiyatları",
    lead: "SMS onay fiyatları seçilen platforma ve ülkeye göre farklılık gösterir. Onay Merkezi'nde temel servisler 15 TL'den başlar; her işlem için ödeyeceğiniz tutar satın alma adımına geçmeden önce açık şekilde listelenir.",
    image: "/assets/images/seo-global-numaralar.jpg",
    imageAlt: "Platform ve ülkelere göre SMS onay fiyatları karşılaştırması",
    imageCaption: "Tüm servislerde şeffaf TL bazlı fiyatlandırma ve bonus bakiye imkanları.",
    sections: [
      {
        id: "platform-fiyatlari",
        h2: "Platformlara Göre SMS Onay Başlangıç Fiyatları",
        paragraphs: [
          "Onay Merkezi ana servis listesinde yer alan platformların başlangıç tarifeleri şu şekildedir: WhatsApp 15 TL, Telegram 15 TL, Google/Gmail 18 TL, Instagram 20 TL, Facebook 20 TL, Discord 22 TL, TikTok 25 TL ve WhatsApp Business 25 TL (Türkiye Business 68 TL)."
        ]
      },
      {
        id: "ulke-farki",
        h2: "Ülke Seçiminin Fiyat Üzerindeki Etkisi",
        paragraphs: [
          "Ülke bazlı listelerde Asya bölgesi (Endonezya, Filipinler, Pakistan, Bangladeş) en uygun fiyatlı grubu oluştururken, Türkiye (+90) numaraları 65–68 TL aralığındadır. Almanya, Fransa, Hollanda, İtalya ve İspanya gibi Avrupa ülkeleri 75–85 TL; ABD, Kanada ve İsviçre numaraları ise 90–130 TL bandındadır."
        ]
      },
      {
        id: "operator-farki",
        h2: "Operatörlere Göre Fiyat Değişimi",
        paragraphs: [
          "Seçtiğiniz ülke içinde birden çok operatör yer aldığında, en ekonomik operatör taban fiyattan sunulur; alternatif operatörler ise birkaç TL farkla sıralanır. Stok adedi ve tahmini iletim bilgileri doğrudan kart üzerinde görülür."
        ]
      },
      {
        id: "indirim-avantaji",
        h2: "Bakiye Bonusları ile Daha Ekonomik SMS Onay",
        paragraphs: [
          "Bakiye Yükle sayfasında 250 TL yatırıldığında %30, 500 TL ve üzeri yatırımlarda %35 ek bonus bakiye tanımlanır. Bu fırsat özellikle ajanslar, sosyal medya yöneticileri ve düzenli doğrulama yapan kullanıcılar için önemli bir maliyet avantajı sağlar."
        ]
      }
    ],
    table: {
      title: "Onay Merkezi Servis Başlangıç Fiyatları",
      headers: ["Platform", "Başlangıç Fiyatı", "Türkiye (+90) / Not"],
      rows: [
        ["WhatsApp", "15 TL", "Türkiye 65 TL"],
        ["Telegram", "15 TL", "60+ ülke seçeneği"],
        ["Google / Gmail", "18 TL", "Google hesap doğrulama"],
        ["Instagram", "20 TL", "SMS aktivasyon kodu"],
        ["Facebook", "20 TL", "SMS aktivasyon kodu"],
        ["Discord", "22 TL", "Telefon doğrulama için"],
        ["TikTok", "25 TL", "Hesap doğrulama"],
        ["WhatsApp Business", "25 TL", "Türkiye Business 68 TL"]
      ]
    },
    steps: {
      title: "Fiyat Karşılaştırma ve Sipariş Adımları",
      items: [
        { label: "Adım 1", title: "Servis Listesini Açın", desc: "Ana sayfada her uygulamanın yanında yazan başlangıç fiyatını görün." },
        { label: "Adım 2", title: "Ülke Kartlarını İnceleyin", desc: "Bölge filtreleriyle bütçenize uygun ülkeyi seçin." },
        { label: "Adım 3", title: "Operatör Seçeneklerine Bakın", desc: "Fiyat ve stok dengesine göre uygun operatöre tıklayın." },
        { label: "Adım 4", title: "Bonuslu Bakiye Yükleyin", desc: "250 TL veya 500 TL üzeri yüklemelerle %30-%35 bonus kazanın." }
      ]
    },
    faqs: [
      { q: "En uygun fiyatlı SMS onay hangi servislerde?", a: "WhatsApp ve Telegram 15 TL'den başlayan fiyatlarla en ekonomik servislerdir." },
      { q: "SMS gelmezse ödediğim ücret yanar mı?", a: "Hayır. Kod ulaşmadığında 2 dakika sonrası iptal veya 10 dakika zaman aşımı ile ücret bakiyenize iade edilir." },
      { q: "Fiyatlara gizli işlem ücreti ekleniyor mu?", a: "Hayır. Numara kartında yazan tutar dışında ek kesinti uygulanmaz." },
      { q: "Bakiye alt sınırı neden 100 TL?", a: "Ödeme süreçlerinin sağlıklı yürütülmesi ve kullanıcıların birden fazla işlem yapabilmesi için minimum yükleme 100 TL olarak belirlenmiştir." },
      { q: "Oyun jetonları fiyatları SMS onaydan ayrı mı?", a: "Evet. PUBG, Free Fire, Valorant, Mobile Legends ve Steam paketleri ana sayfada ayrı bir kategori olarak sunulur." }
    ],
    related: ["sanal-numara-fiyatlari", "whatsapp-sanal-numara-fiyatlari", "ucuz-sanal-numara", "sanal-numara-odeme-yontemleri", "sms-onay-satin-al", "sms-onay"]
  },
  {
    slug: "sms-kodu-alma",
    menuLabel: "SMS Kodu Alma",
    category: "SMS Onay Rehberleri",
    title: "SMS Doğrulama Kodu Alma Rehberi | Onay Merkezi",
    description: "Online SMS doğrulama kodu nasıl alınır? Tek kullanımlık OTP mesajlarının panele düşme süresi, kopyalama ve hata önleme ipuçları.",
    h1: "SMS Doğrulama Kodu Alma Rehberi",
    lead: "SMS doğrulama kodu alma süreci, telefon numaranızı paylaşmadan web paneli üzerinden tek seferlik güvenlik şifresini (OTP) görüntülemenize olanak tanır. İşlemin hızlı sonuçlanması için kodun gönderilme sırasını ve zamanlayıcı kurallarını doğru takip etmek yeterlidir.",
    image: "/assets/images/seo-whatsapp-dogrulama.jpg",
    imageAlt: "Web panelinden tek kullanımlık SMS doğrulama kodu alma",
    imageCaption: "Her 2 saniyede bir yenilenen canlı kontrol ile otomatik OTP kodu görüntüleme.",
    sections: [
      {
        id: "otp-nedir",
        h2: "Tek Kullanımlık SMS Doğrulama Kodu (OTP) Nasıl İletilir?",
        paragraphs: [
          "Bir uygulamaya telefon numaranızı girdiğinizde uygulama sunucusu 4, 5 veya 6 haneli bir sayı dizisi üretir ve uluslararası SMS ağları üzerinden numaraya yollar. Onay Merkezi bu mesajı yakalayarak doğrudan açık sipariş kartınızdaki yeşil kod panelinde gösterir."
        ]
      },
      {
        id: "zamanlama",
        h2: "Zamanlayıcı ve Otomatik Kontrol Mekanizması",
        paragraphs: [
          "Sipariş oluşturulduğu anda 10:00 dakikalık geri sayım başlar ve sistem her 2 saniyede bir gelen kutusunu kontrol eder. Sayfayı manuel olarak sürekli yenilemenize gerek yoktur; kod ulaştığında ekranda ses/görsel güncelleme ile birlikte 'Kodu Kopyala' butonu çıkar."
        ]
      },
      {
        id: "dogru-sirali-islem",
        h2: "Kod Alırken En Sık Gözden Kaçan Detaylar",
        paragraphs: [
          "SMS kodunu sorunsuz almak için şu pratik kurallara uymak yeterlidir:"
        ],
        list: [
          "Önce Onay Merkezi'nden numarayı alın, sonra uygulamada 'Kod Gönder' tuşuna basın.",
          "Uygulamada ülke kodu seçiliyken numarayı tekrar ülke koduyla yapıştırmayın.",
          "Kod gelmeden uygulama ekranını kapatıp yeni bir deneme başlatmayın; aksi halde gelen kod geçersiz kalabilir.",
          "2 dakika boyunca mesaj ulaşmazsa iptal butonunu kullanıp başka operatöre geçin."
        ]
      },
      {
        id: "kod-gecmisi",
        h2: "Alınan Kodların Kaydı ve Tekrar Erişim",
        paragraphs: [
          "Kodu aldıktan sonra ekrandan yanlışlıkla çıksanız bile endişelenmeyin; alt navigasyon çubuğundaki 'Siparişler' sekmesinde geçmiş siparişleriniz ve aldığınız kodlar kayıtlı kalır."
        ]
      }
    ],
    table: {
      title: "SMS Kodu Alma Süreç Aşamaları",
      headers: ["Süre Aralığı", "Panel Durumu", "Yapılması Gereken"],
      rows: [
        ["0:00 – 2:00 dk", "İlk SMS bekleme süreci", "Uygulamadan kodu isteyin ve bekleyin"],
        ["2:00 – 10:00 dk", "İptal butonu aktifleşir", "Kod gelmediyse iptal edebilir veya bekleyebilirsiniz"],
        ["Kod Ulaştığında", "Yeşil kod kutusu açılır", "Kodu kopyalayıp uygulamaya girin"],
        ["10:00 dk Sonu", "Zaman aşımı", "Kod gelmediyse bakiye otomatik iade edilir"]
      ]
    },
    steps: {
      title: "SMS Doğrulama Kodu Alma Adımları",
      items: [
        { label: "Adım 1", title: "Numarayı Sipariş Edin", desc: "Servis, ülke ve operatör seçip numarayı ekrana getirin." },
        { label: "Adım 2", title: "Numarayı Kopyalayın", desc: "Kopyala butonuyla numarayı hatasız şekilde panoya alın." },
        { label: "Adım 3", title: "Uygulamadan SMS İsteyin", desc: "Doğrulama ekranında sesli arama yerine SMS seçeneğine dokunun." },
        { label: "Adım 4", title: "Kodu Kopyalayıp Girin", desc: "Yeşil panelde çıkan kodu kopyalayıp uygulamayı onaylayın." }
      ]
    },
    faqs: [
      { q: "SMS doğrulama kodunu görmek için sayfayı yenilemeli miyim?", a: "Hayır. Sipariş ekranı her 2 saniyede bir otomatik kontrol yapar ve kod geldiğinde kendiliğinden ekrana yansır." },
      { q: "Kod geldi ama uygulama kabul etmedi, neden olabilir?", a: "Genellikle eski bir oturum kodu girildiğinde veya zaman aşımı yaklaştığında yaşanır; uygulamada doğru kodu hızlıca girmek önemlidir." },
      { q: "Aynı numaraya ikinci bir SMS kodu isteyebilir miyim?", a: "Çoğu aktivasyon hattı tek mesaj için yapılandırılmıştır; ikinci kod gerekiyorsa yeni numara almak daha sağlıklıdır." },
      { q: "Kod geldikten sonra iptal iadesi olur mu?", a: "Hayır. SMS kodu başarıyla teslim edildikten sonra hizmet tamamlanmış kabul edilir ve iade yapılmaz." },
      { q: "Kodun süresi dolmadan nereye girmeliyim?", a: "Doğrulama yaptığınız uygulamanın (WhatsApp, Telegram, Instagram vb.) kod kutusuna doğrudan yazmalısınız." }
    ],
    related: ["sms-kodu-gelmiyor", "whatsapp-sms-kodu", "sms-dogrulama", "sms-onay", "sms-onay-nasil-calisir", "sms-onay-iade"]
  },
  {
    slug: "mobil-onay",
    menuLabel: "Mobil Onay",
    category: "SMS Onay Rehberleri",
    title: "Mobil Onay Nedir? Sanal Numara ile Mobil Onay | Onay Merkezi",
    description: "Mobil onay nedir, dijital platformlarda neden istenir ve sanal numarayla mobil onay nasıl yapılır? Hızlı ve pratik mobil onay rehberi.",
    h1: "Mobil Onay Nedir?",
    lead: "Mobil onay, internet servisleri ve mobil uygulamaların kullanıcı hesabını bir GSM hattı üzerinden SMS kodu ile doğrulama işlemidir. Günlük dilde SMS onay ile eş anlamlı olarak kullanılan mobil onay, kişisel hattınızı paylaşmadan Onay Merkezi üzerinden kolayca tamamlanabilir.",
    image: "/assets/images/seo-whatsapp-dogrulama.jpg",
    imageAlt: "Mobil onay sistemi ve akıllı telefon doğrulama ekranı",
    imageCaption: "Fiziksel GSM hattına ihtiyaç duymadan dijital mobil onay süreci.",
    sections: [
      {
        id: "mobil-onay-tanimi",
        h2: "Mobil Onay Kavramı ve Günlük Kullanımı",
        paragraphs: [
          "E-ticaret sitelerinden mesajlaşma uygulamalarına, oyun platformlarından sosyal ağlara kadar pek çok servis kayıt aşamasında 'mobil onay' ister. Bunun amacı, aynı kişinin yüzlerce sahte hesap açmasını zorlaştırmak ve gerektiğinde hesaba telefon üzerinden bildirim ulaştırmaktır."
        ]
      },
      {
        id: "sanal-hat-ile-mobil-onay",
        h2: "Sanal Numara ile Mobil Onay Yapmanın Avantajları",
        paragraphs: [
          "Her kayıt olduğunuz platforma kendi kişisel numaranızı vermek hem reklam aramalarını artırır hem de veri gizliliğinizi zayıflatır. Sanal numara ile mobil onay yaptığınızda:"
        ],
        list: [
          "Kişisel telefon numaranız yalnızca güvendiğiniz mecralarda kalır.",
          "İkinci veya üçüncü hesaplar için yeni bir SIM kart satın almanız gerekmez.",
          "60'tan fazla ülke seçeneğiyle uluslararası servislerde de mobil onay geçilebilir.",
          "Kod ulaşmadığında 2 dakika sonrası iptal ve 10 dakika zaman aşımı iadesiyle bütçeniz korunur."
        ]
      },
      {
        id: "desteklenen-uygulamalar",
        h2: "Hangi Uygulamalar Mobil Onay İster?",
        paragraphs: [
          "WhatsApp, WhatsApp Business, Telegram, Instagram, Facebook, TikTok, Discord ve Google/Gmail gibi platformların tamamı hesap açılışında veya şüpheli oturumlarda mobil onay talep edebilir. Onay Merkezi bu servislerin tamamı için ayrı kategoriler sunar."
        ]
      },
      {
        id: "mobil-onay-sinirlari",
        h2: "Mobil Onayda Kalıcılık Konusu",
        paragraphs: [
          "Geçici mobil onay hatları doğrulamayı tamamlamak için idealdir. Ancak bankacılık, e-Devlet veya kripto borsası gibi sürekli SMS ile giriş isteyen finansal platformlarda daima kendi adınıza kayıtlı kalıcı mobil hattınızı kullanmalısınız."
        ]
      }
    ],
    table: {
      title: "Mobil Onay Kullanım Alanları ve Uygunluk",
      headers: ["Alan", "Mobil Onay Kullanımı", "Tavsiye"],
      rows: [
        ["Mesajlaşma (WhatsApp / Telegram)", "Sanal numara ile uygun", "Kurulum sonrası 2FA şifresi ekleyin"],
        ["Sosyal Medya (Instagram / TikTok / X)", "Sanal numara ile uygun", "E-posta doğrulamasını da bağlayın"],
        ["Topluluk / Oyun (Discord)", "Sanal numara ile uygun", "Kullanıcı adı ve şifreyi saklayın"],
        ["Bankacılık / Resmi Kurum", "Kişisel hat gerekir", "Geçici numara kullanmayın"]
      ]
    },
    steps: {
      title: "Mobil Onay Tamamlama Adımları",
      items: [
        { label: "Adım 1", title: "Servisi Belirleyin", desc: "Mobil onay isteyen uygulamayı Onay Merkezi servis listesinde seçin." },
        { label: "Adım 2", title: "Ülke Tercihi Yapın", desc: "Türkiye (+90) veya yurtdışı ülke kartlarından birini seçin." },
        { label: "Adım 3", title: "Numarayı Girin", desc: "Aldığınız numarayı uygulamanın telefon kutusuna yazın." },
        { label: "Adım 4", title: "Gelen Kodu Onaylayın", desc: "Sipariş ekranına yansıyan kodu uygulamaya girerek mobil onayı bitirin." }
      ]
    },
    faqs: [
      { q: "Mobil onay ile SMS onay arasında fark var mı?", a: "Hayır, pratikte aynı işlemi ifade eder. İkisi de uygulamaların telefon numarasına gönderdiği doğrulama kodunun girilmesidir." },
      { q: "Mobil onay için telefonuma uygulama yüklemem gerekiyor mu?", a: "Hayır, Onay Merkezi mobil tarayıcınızdan veya bilgisayarınızdan doğrudan çalışır." },
      { q: "Mobil onay ücreti ne kadar?", a: "Seçilen servis ve ülkeye göre 15 TL'den başlayan fiyatlarla sunulmaktadır." },
      { q: "Kod gelmezse ödediğim tutar ne olur?", a: "2 dakika sonra iptal ettiğinizde ya da 10 dakikalık süre dolduğunda bakiye hesabınıza iade edilir." },
      { q: "Mobil onay sonrası profilime kendi e-postamı ekleyebilir miyim?", a: "Evet, doğrulama tamamlandıktan sonra uygulama ayarlarından kendi e-postanızı eklemeniz güvenliğiniz için önerilir." }
    ],
    related: ["sms-onay", "sms-dogrulama", "sanal-numara-nedir", "sms-onay-satin-al", "whatsapp-sms-onay", "sms-onay-rehberi"]
  },
  {
    slug: "sms-dogrulama",
    menuLabel: "SMS Doğrulama",
    category: "SMS Onay Rehberleri",
    title: "SMS Doğrulama Nasıl Yapılır? Adım Adım Kılavuz | Onay Merkezi",
    description: "SMS doğrulama işlemi nasıl yapılır? Sanal numarayla OTP kodu alma, ülke kodu formatı, hata çözümü ve güvenli doğrulama adımları.",
    h1: "SMS Doğrulama Nasıl Yapılır?",
    lead: "SMS doğrulama, çevrimiçi hesapların güvenliğini sağlamak için telefona gönderilen tek kullanımlık şifrenin uygulamaya girilmesi işlemidir. Fiziksel hattınızı paylaşmadan hızlıca SMS doğrulama yapmak için sanal numara altyapısından yararlanabilirsiniz.",
    image: "/assets/images/seo-whatsapp-dogrulama.jpg",
    imageAlt: "Adım adım SMS doğrulama yapma ve kod giriş ekranı",
    imageCaption: "Doğru formatta numara girişi ve anlık OTP kodu doğrulaması.",
    sections: [
      {
        id: "dogrulama-hazirligi",
        h2: "SMS Doğrulama Öncesinde Dikkat Edilmesi Gerekenler",
        paragraphs: [
          "Doğrulama sürecine başlamadan önce kullanacağınız uygulamanın güncel olduğundan emin olun. Bazı platformlar aynı cihazdan kısa sürede çok fazla hesap açmaya çalışıldığında SMS göndermeyi geçici olarak durdurabilir; bu yüzden işlemi sakin ve sıralı biçimde yürütmek önemlidir."
        ]
      },
      {
        id: "numara-ve-ulke",
        h2: "Ülke Kodu ve Operatör Eşleştirme",
        paragraphs: [
          "Onay Merkezi'nden aldığınız numaranın ülke kodunu doğrulama yapacağınız uygulamada eksiksiz seçmelisiniz. Örneğin Almanya (+49) numarası aldıysanız uygulamada Almanya seçili olmalı, numaranın geri kalan kısmı başına sıfır veya +49 eklenmeden girilmelidir."
        ]
      },
      {
        id: "bekleme-ve-kontrol",
        h2: "Kodun Ulaşması ve Sipariş Ekranı Takibi",
        paragraphs: [
          "Doğrulama isteğini gönderdikten sonra Onay Merkezi sipariş kartındaki zamanlayıcı 10 dakikadan geriye sayarken sistem otomatik olarak kodu bekler. Mesaj ulaştığında kod kutusu yeşil renkle görünür. Kodu tek tıkla kopyalayıp uygulamaya yapıştırabilirsiniz."
        ]
      },
      {
        id: "dogrulama-basarisizsa",
        h2: "Doğrulama Kodu Ulaşmazsa Alternatif Yol",
        paragraphs: [
          "İlk operatörden 2 dakika boyunca SMS gelmezse iptal butonuna tıklayarak bakiyenizi geri alabilir, ardından aynı ülkede başka bir operatör ya da listedeki farklı bir ülkeyi seçerek doğrulama işlemini tekrarlayabilirsiniz."
        ]
      }
    ],
    table: {
      title: "SMS Doğrulama Sürecinde Hızlı Kontrol Tablosu",
      headers: ["Adım", "Kontrol Edilecek Nokta", "Doğru Uygulama"],
      rows: [
        ["1. Servis Seçimi", "Hedef platform adı", "Örn. Gmail için Google/Gmail seçilmeli"],
        ["2. Numara Girişi", "Ülke kodu tekrarı", "Başında 0 veya çift +90 olmadan girilmeli"],
        ["3. Kod İsteği", "SMS vs Sesli Arama", "Her zaman SMS seçeneği tercih edilmeli"],
        ["4. Zamanlama", "2 dk / 10 dk kuralı", "Kod yoksa 2 dk sonra iptal hakkı kullanılmalı"]
      ]
    },
    steps: {
      title: "4 Adımda Hatasız SMS Doğrulama",
      items: [
        { label: "Adım 1", title: "Doğru Servisi Açın", desc: "Onay Merkezi'nden doğrulayacağınız uygulamayı seçin." },
        { label: "Adım 2", title: "Ülke ve Operatör Seçin", desc: "Uygun bütçe ve stok durumuna göre tercihinizi yapın." },
        { label: "Adım 3", title: "Numarayı Uygulamaya Girin", desc: "Ülke kodunu kontrol ederek numarayı doğrulama ekranına yazın." },
        { label: "Adım 4", title: "Gelen Kodu Girin", desc: "Panelden okuduğunuz kodu uygulamaya girerek doğrulamayı tamamlayın." }
      ]
    },
    faqs: [
      { q: "SMS doğrulama kodu kaç hanelidir?", a: "Platforma göre değişir; genellikle 4, 5 veya 6 haneli sayısal kodlardan oluşur." },
      { q: "Kod geldikten sonra kaç saniye içinde girmeliyim?", a: "Uygulamaların OTP kodları kısa süreli geçerli olduğu için kod panele düştüğü anda vakit kaybetmeden girmeniz önerilir." },
      { q: "SMS doğrulama sırasında internet kesilirse ne olur?", a: "İnternetiniz geri geldiğinde hesabınızla tekrar giriş yapıp Siparişler sekmesinden gelen kodu görebilirsiniz." },
      { q: "Aynı telefon numarasıyla iki kez doğrulama yapabilir miyim?", a: "Tek kullanımlık numaralarda her sipariş tek bir aktivasyon içindir." },
      { q: "Yabancı ülke numarasıyla Türkçe hesap doğrulayabilir miyim?", a: "Evet. Numaranın ülke kodu yalnızca telefon hattının bölgesini belirtir, hesap dilini değiştirmez." }
    ],
    related: ["sms-onay", "sms-kodu-alma", "sms-kodu-gelmiyor", "whatsapp-numara-dogrulama", "mobil-onay", "sanal-numara-kullanimi"]
  },
  {
    slug: "sms-onay-guvenligi",
    menuLabel: "SMS Onay Güvenliği",
    category: "SMS Onay Rehberleri",
    title: "SMS Onay Güvenliği: Gizlilik ve Hesap Koruma | Onay Merkezi",
    description: "SMS onay kullanırken kişisel verileriniz ve yeni açtığınız hesaplar nasıl korunur? Güvenli ödeme, 2FA önlemleri ve KVKK uyumu rehberi.",
    h1: "SMS Onay Güvenliği",
    lead: "SMS onay hizmetlerinden yararlanırken hem kendi kişisel verilerinizi hem de doğruladığınız hesapların geleceğini korumak önemlidir. Güvenli bir deneyim; kapalı kullanıcı paneli, şeffaf veri politikası ve kurulum sonrası ek güvenlik ayarlarının birleşimiyle sağlanır.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "SMS onay güvenliği ve kullanıcı hesabı koruma katmanları",
    imageCaption: "Siparişe özel kod teslimatı, KVKK uyumu ve hesap içi iki adımlı doğrulama.",
    sections: [
      {
        id: "gizli-kod-teslimi",
        h2: "Gelen SMS Kodlarının Gizliliği",
        paragraphs: [
          "Güvenli bir SMS onay altyapısında gelen doğrulama kodları halka açık sayfalarda yayınlanmaz. Onay Merkezi'nde her numara siparişi doğrudan oturum açmış kullanıcının kendi hesabına bağlıdır; gelen kod yalnızca kullanıcının kendi sipariş ekranında ve sipariş geçmişinde görüntülenir."
        ]
      },
      {
        id: "odeme-ve-hesap-koruma",
        h2: "Ödeme ve Üyelik Güvenliği",
        paragraphs: [
          "Hesap güvenliği için güçlü ve benzersiz bir şifre belirlemeniz, oturumunuzu ortak cihazlarda açık bırakmamanız gerekir. Bakiye yüklerken dilerseniz kartla ödeme ekranını, dilerseniz hiçbir kart bilgisi girmeden IBAN ile Havale/EFT bildirim yöntemini kullanabilirsiniz."
        ]
      },
      {
        id: "hesap-devralma-onleme",
        h2: "Doğrulanan Hesapların Sonradan Korunması",
        paragraphs: [
          "Geçici numara ile bir hesap doğruladıktan sonra güvenliği kalıcı hale getirmek için şu önlemleri uygulamalısınız:"
        ],
        list: [
          "WhatsApp ve Telegram'da mutlaka iki adımlı doğrulama (ek PIN/parola) oluşturun.",
          "Instagram, Google, Discord ve X gibi hesaplara kendi aktif e-posta adresinizi bağlayın.",
          "Şifre kurtarma seçeneklerinde telefon yerine kurtarma kodları veya authenticator uygulaması (TOTP) tanımlayın."
        ]
      },
      {
        id: "yasal-ve-etik-sinir",
        h2: "Yasal Kullanım ve Kötüye Kullanım Önleme",
        paragraphs: [
          "Kullanım Koşulları uyarınca sanal numara ve SMS onay hizmetleri yalnızca yasal iletişim, test ve kişisel gizlilik amaçlıdır. Herhangi bir yasa dışı faaliyet veya spam kullanımı kesinlikle kabul edilmez."
        ]
      }
    ],
    table: {
      title: "SMS Onay Güvenlik Katmanları",
      headers: ["Katman", "Platform Önlemi", "Kullanıcı Sorumluluğu"],
      rows: [
        ["Kod Teslimatı", "Yalnızca üye hesabına özel gösterim", "Kodu üçüncü kişilerle paylaşmamak"],
        ["Veri İşleme", "KVKK & Gizlilik Politikası metinleri", "Doğru ve güvenli şifre seçmek"],
        ["Hesap Devamlılığı", "Tek kullanımlık aktivasyon uyarısı", "Hesaba 2FA PIN ve kurtarma e-postası eklemek"],
        ["Ödeme Süreci", "Alternatif IBAN / Kart seçenekleri", "Ödeme bildirimini doğru bilgilerle girmek"]
      ]
    },
    steps: {
      title: "Güvenli SMS Onay İçin 4 Adımlı Kontrol",
      items: [
        { label: "Adım 1", title: "Özgün Şifre Kullanın", desc: "Panel hesabınız için başka sitelerde kullanmadığınız bir şifre seçin." },
        { label: "Adım 2", title: "Doğru Ödeme Yöntemini Seçin", desc: "İhtiyacınıza göre IBAN Havale/EFT veya kart ödeme yöntemini tercih edin." },
        { label: "Adım 3", title: "Kodu Kimseyle Paylaşmayın", desc: "Sipariş ekranınıza düşen OTP kodunu sadece uygulamaya girin." },
        { label: "Adım 4", title: "2FA ile Kilitleyin", desc: "Hesap açılır açılmaz iki adımlı doğrulama ve kurtarma e-postası ekleyin." }
      ]
    },
    faqs: [
      { q: "Aldığım SMS onay kodunu başka bir üye görebilir mi?", a: "Hayır. Sipariş ve gelen SMS mesajı yalnızca sizin üye hesabınıza bağlıdır." },
      { q: "Onay Merkezi verilerimi üçüncü taraflarla paylaşır mı?", a: "Gizlilik Politikası ve KVKK Aydınlatma Metni kapsamında veriler yalnızca hizmetin sunulması amacıyla işlenir." },
      { q: "En güvenli bakiye yükleme yöntemi hangisidir?", a: "Kart bilgisini paylaşmak istemeyen kullanıcılar IBAN ile Havale/EFT yapıp bildirim formunu kullanarak bakiye yükleyebilir." },
      { q: "Sanal numarayla açtığım hesaba başkasının erişmesini nasıl önlerim?", a: "Uygulama ayarlarından İki Adımlı Doğrulama (2FA PIN/şifre) ve kurtarma e-postası tanımlayarak erişimi koruyabilirsiniz." },
      { q: "Şüpheli bir durum fark edersem nereye bildirmeliyim?", a: "Canlı Destek sohbetinden veya destek@onaymerkezi.org adresinden ekibe hemen ulaşabilirsiniz." }
    ],
    related: ["sanal-numara-guvenilir-mi", "whatsapp-numara-guvenligi", "onay-merkezi-guvenilir-mi", "numara-alirken-dikkat-edilmesi-gerekenler", "sms-onay-siteleri", "sanal-numara-odeme-yontemleri"]
  },
  {
    slug: "sms-kodu-gelmiyor",
    menuLabel: "SMS Kodu Gelmiyor",
    category: "SMS Onay Rehberleri",
    title: "SMS Kodu Gelmiyor: Nedenleri ve Çözümleri | Onay Merkezi",
    description: "Sanal numara aldıktan sonra SMS onay kodu gelmiyor mu? Operatör gecikmeleri, hatalı ülke kodu, 2 dakika iptal kuralı ve kesin çözümler.",
    h1: "SMS Kodu Gelmiyor: Nedenleri ve Çözümleri",
    lead: "Sanal numara kullanırken doğrulama kodunun beklenen sürede ekrana düşmemesi sıkça karşılaşılan ve çözümü olan bir durumdur. Nedenin operatörden, numara formatından ya da uygulama içi kısıtlamalardan kaynaklandığını tespit ederek sorunu birkaç dakikada aşabilirsiniz.",
    image: "/assets/images/seo-whatsapp-dogrulama.jpg",
    imageAlt: "SMS onay kodu gelmiyor sorununun nedenleri ve çözüm adımları",
    imageCaption: "Operatör değişikliği, doğru format ve 2 dakika sonrası iade ile hızlı çözüm.",
    sections: [
      {
        id: "nedenler",
        h2: "SMS Kodu Neden Gelmez? 5 Yaygın Sebep",
        paragraphs: [
          "Kodun panele ulaşmamasının en yaygın nedenleri şunlardır:"
        ],
        list: [
          "Operatör Yoğunluğu: Seçilen operatörün SMS geçidinde anlık gecikme veya tıkanıklık yaşanıyor olabilir.",
          "Hatalı Numara Formatı: Uygulamada ülke kodu zaten seçiliyken numarayı tekrar ülke koduyla veya başında 0 ile yazmak mesajın gitmesini engeller.",
          "Cihaz İçi Sık Deneme Kilidi: Aynı cihazdan dakikalar içinde art arda çok fazla doğrulama istemek uygulamanın SMS gönderimini durdurmasına yol açar.",
          "Sesli Arama Seçilmesi: 'Beni Ara' seçeneği yerine mutlaka 'SMS Gönder' seçeneği kullanılmalıdır.",
          "Platform Filtresi: İlgili ülke veya numara serisi o uygulama tarafından geçici olarak kısıtlanmış olabilir."
        ]
      },
      {
        id: "cozum-iptal-iade",
        h2: "Onay Merkezi'nde İptal ve İade ile Hızlı Çözüm",
        paragraphs: [
          "Sipariş ekranında 10 dakikalık geri sayım başlar. İlk 2 dakika dolduğunda 'İptal Et ve İade Al' butonu aktifleşir. Kod hala düşmediyse bu butona basarak ödediğiniz tutarı anında bakiyenize geri alabilirsiniz. 10 dakika sonunda kod gelmezse iade otomatik gerçekleşir."
        ]
      },
      {
        id: "operator-ve-ulke-degisimi",
        h2: "Operatör ve Ülke Değiştirme Stratejisi",
        paragraphs: [
          "İade aldığınız bakiyeyle aynı numarayı zorlamak yerine önce aynı ülke altındaki farklı bir operatörü (örneğin Sanal94 yerine Sanal95 veya Sanal53) deneyin. Yine sonuç alamazsanız farklı bir ülke alan koduna geçmek genellikle sorunu hemen çözer."
        ]
      },
      {
        id: "uygulama-temizligi",
        h2: "Uygulama ve Tarayıcı Tarafında Alınacak Önlemler",
        paragraphs: [
          "Özellikle Google, Instagram veya WhatsApp gibi platformlarda art arda başarısız denemelerden sonra uygulama önbelleğini temizlemek, VPN'i kapatmak veya temiz bir tarayıcı sekmesinden ilerlemek doğrulama isteğinin kabul edilme olasılığını artırır."
        ]
      }
    ],
    table: {
      title: "SMS Kodu Gelmeme Durumuna Göre Hızlı Müdahale",
      headers: ["Durum", "Yapılmaması Gereken", "Doğru Çözüm"],
      rows: [
        ["2 dakikadır kod yok", "Aynı numarayı 5 kez tekrar istemek", "2 dk sonunda iptal edip başka operatör seçin"],
        ["'Beni Ara' uyarısı çıktı", "Sesli arama beklemek", "SMS seçeneği yoksa iptal edip farklı ülke deneyin"],
        ["Numara yanlış uyarısı", "Tekrar tekrar aynı şekilde girmek", "Ülke kodunu ve baştaki 0'ı kontrol edin"],
        ["Süre 10 dakikaya ulaştı", "Panik yapmak", "Sistem bakiyeyi otomatik iade eder, yeniden sipariş verin"]
      ]
    },
    steps: {
      title: "Kod Gelmediğinde İzlenecek 4 Adım",
      items: [
        { label: "Adım 1", title: "Numara Girişini Gözden Geçirin", desc: "Ülke kodu ve rakamların eksiksiz girildiğini doğrulayın." },
        { label: "Adım 2", title: "2 Dakikalık Süreyi Bekleyin", desc: "Sipariş panelindeki sayacın 2 dakikayı geçmesini bekleyin." },
        { label: "Adım 3", title: "İptal Et ve İade Al'a Basın", desc: "Aktifleşen kırmızı iptal butonuyla bakiyenizi kesintisiz geri alın." },
        { label: "Adım 4", title: "Başka Operatör/Ülke Deneyin", desc: "Farklı bir operatör veya alternatif ülke seçerek tekrar sipariş verin." }
      ]
    },
    faqs: [
      { q: "SMS kodu neden bazen 5 dakika sonra gelir?", a: "Uluslararası operatör yönlendirmelerinde anlık yoğunluğa bağlı olarak mesajın panele düşmesi birkaç dakika sürebilir." },
      { q: "2 dakika dolmadan iptal edebilir miyim?", a: "İlk 2 dakika SMS'in ulaşması için ayrılan standart süredir; bu nedenle iptal butonu tam 2. dakikada aktifleşir." },
      { q: "İptal ettiğimde bakiyemden komisyon kesilir mi?", a: "Hayır. Sipariş için ödediğiniz tutarın tamamı bakiyenize geri eklenir." },
      { q: "Kod gelmediği için canlı desteğe yazmam gerekir mi?", a: "Standart iadeler 2 dakika sonrası iptal butonuyla veya 10 dakika sonunda otomatik yapılır; ek bir sorun yaşarsanız Canlı Destek'e yazabilirsiniz." },
      { q: "VPN açıkken kod gelmemesi normal mi?", a: "Bazı uygulamalar şüpheli VPN IP'lerinden gelen kod isteklerini sessizce engelleyebilir. Mümkünse normal bağlantıyla deneyin." }
    ],
    related: ["whatsapp-sms-kodu", "sms-onay-iade", "sms-kodu-alma", "whatsapp-numara-dogrulama", "sms-dogrulama", "numara-alirken-dikkat-edilmesi-gerekenler"]
  },
  {
    slug: "sms-onay-rehberi",
    menuLabel: "SMS Onay Rehberi",
    category: "SMS Onay Rehberleri",
    title: "Kapsamlı SMS Onay Rehberi | A'dan Z'ye | Onay Merkezi",
    description: "A'dan Z'ye kapsamlı SMS onay rehberi: nedir, nasıl alınır, hangi ülkeler seçilmeli, ödeme yöntemleri, iade süreci ve hesap güvenliği.",
    h1: "Kapsamlı SMS Onay Rehberi",
    lead: "SMS onay sürecini ilk kez kullanacak veya tüm detaylarını tek bir kaynakta görmek isteyenler için hazırlanan bu kapsamlı rehberde; servis seçiminden ülke fiyatlarına, ödeme adımlarından iade mekanizmasına ve hesap güvenliğine kadar tüm aşamalar bir arada sunulmaktadır.",
    image: "/assets/images/seo-global-numaralar.jpg",
    imageAlt: "Kapsamlı SMS onay rehberi ve 4 adımlı onay süreci",
    imageCaption: "Servis seçimi, ödeme, OTP kodu alımı ve güvenlik aşamalarının tamamı.",
    sections: [
      {
        id: "genel-bakis",
        h2: "1. SMS Onay Sisteminin Temel Mantığı",
        paragraphs: [
          "SMS onay, fiziksel SIM kart taşımadan çevrimiçi platformların istediği telefon doğrulamasını geçmenizi sağlayan bulut tabanlı numara servisidir. Onay Merkezi'nde tek ekran üzerinden WhatsApp, Telegram, Instagram, Google/Gmail, Facebook, TikTok ve Discord için numara temin edebilirsiniz."
        ]
      },
      {
        id: "bakiye-ve-kampanya",
        h2: "2. Bakiye Yönetimi ve Ödeme Seçenekleri",
        paragraphs: [
          "Hesap oluşturduktan sonra minimum 100 TL bakiye yükleyerek işleme başlarsınız. Ödemelerinizi IBAN ile Havale/EFT bildirimi veya kartla ödeme penceresi aracılığıyla yapabilirsiniz. 250 TL yüklemeye %30, 500 TL ve üzeri yüklemelere %35 bonus bakiye tanımlanır."
        ]
      },
      {
        id: "ulke-operator-secimi",
        h2: "3. Ülke ve Operatör Seçiminde Strateji",
        paragraphs: [
          "60'tan fazla ülke arasında seçim yaparken ihtiyacınızı belirlemek önemlidir. Maliyet odaklı işlemlerde Asya ülkeleri 15 TL'den başlarken, yerel müşteri güveni için Türkiye (+90) 65 TL (Business 68 TL) olarak sunulur. Ülke içindeki farklı operatör seçenekleri alternatif sağlar."
        ]
      },
      {
        id: "iade-ve-guvenlik",
        h2: "4. İade Kuralları ve Hesap Sonrası Güvenlik",
        paragraphs: [
          "Sipariş başlatıldığında 10 dakikalık geri sayım işler. Kod gelmezse 2 dakika sonra iptal edebilir veya 10 dakika sonunda otomatik iade alabilirsiniz. Hesap doğrulandıktan sonra ise daima iki adımlı doğrulama (2FA) ve kurtarma e-postası ekleyerek hesabınızı korumaya almalısınız."
        ]
      }
    ],
    table: {
      title: "Kapsamlı SMS Onay Özet Referansı",
      headers: ["Konu", "Onay Merkezi Standardı", "İlgili Rehber"],
      rows: [
        ["Desteklenen Servisler", "8 ana uygulama + Oyun Jetonları", "WhatsApp, Telegram, Instagram, Gmail vb."],
        ["Ülke Kapsamı", "60+ ülke", "Popüler, Avrupa, Asya, Amerika, Afrika, Orta Doğu"],
        ["Başlangıç Fiyatı", "15 TL'den itibaren", "Ülke ve servise göre şeffaf fiyat"],
        ["İade Güvencesi", "2 dk sonrası iptal / 10 dk otomatik iade", "Kod gelmeyen işlemlerde tam iade"]
      ]
    },
    steps: {
      title: "Baştan Sona SMS Onay Yol Haritası",
      items: [
        { label: "Adım 1", title: "Hesap ve Bakiye", desc: "Kayıt olun ve IBAN veya kartla en az 100 TL bakiye yükleyin." },
        { label: "Adım 2", title: "Servis & Ülke", desc: "Hedef uygulamayı ve istediğiniz ülkeyi belirleyin." },
        { label: "Adım 3", title: "Operatör & Numara", desc: "Stoklu operatörü seçip numarayı uygulamaya yapıştırın." },
        { label: "Adım 4", title: "Kod & 2FA Koruma", desc: "Gelen kodu girin ve hesaba mutlaka iki adımlı doğrulama ekleyin." }
      ]
    },
    faqs: [
      { q: "SMS onay ilk kez kullanacak biri için zor mudur?", a: "Hayır. 4 adımlı görsel rehber (Servis → Ülke → Operatör → Numara) sayesinde herkes kolayca işlem yapabilir." },
      { q: "Aynı hesaptan farklı günlerde tekrar numara alabilir miyim?", a: "Evet, hesabınız ve kalan bakiyeniz sürekli aktif kalır; dilediğiniz zaman yeni sipariş oluşturabilirsiniz." },
      { q: "Hem mobil hem bilgisayardan kullanabilir miyim?", a: "Evet, Onay Merkezi tasarımı hem akıllı telefon ekranlarına hem masaüstü tarayıcılara tam uyumludur." },
      { q: "Aldığım tüm numaraları sonradan görebilir miyim?", a: "Evet, alt menüdeki Siparişler bölümünden tüm geçmiş işlemlerinizi takip edebilirsiniz." },
      { q: "Destek ekibine hangi saatlerde ulaşabilirim?", a: "Canlı Destek sohbet penceresi ve destek@onaymerkezi.org üzerinden destek taleplerinizi iletebilirsiniz." }
    ],
    related: ["sms-onay", "sanal-numara-nasil-alinir", "sms-onay-nasil-calisir", "sanal-numara-sss", "sms-kodu-gelmiyor", "onay-merkezi-guvenilir-mi"]
  }
];
