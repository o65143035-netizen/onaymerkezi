export const PAYMENT_PAGES = [
  {
    slug: "sanal-numara-nasil-alinir",
    menuLabel: "Sanal Numara Nasıl Alınır",
    category: "Satın Alma & Ödeme",
    title: "Sanal Numara Nasıl Alınır? Adım Adım Rehber | Onay Merkezi",
    description: "Sanal numara nasıl alınır? Üyelik açılışı, bakiye yükleme, servis-ülke-operatör seçimi ve 10 dakikalık SMS alma sürecinin tam anlatımı.",
    h1: "Sanal Numara Nasıl Alınır?",
    lead: "Sanal numara alma işlemi yalnızca birkaç dakika süren tamamen dijital bir süreçtir. Fiziksel SIM karta veya kimlik evrakına gerek duymadan, Onay Merkezi hesabınız üzerinden istediğiniz platform ve ülke için anında numara temin edebilirsiniz.",
    image: "/assets/images/seo-whatsapp-dogrulama.jpg",
    imageAlt: "Onay Merkezi üzerinden sanal numara nasıl alınır adım adım rehber",
    imageCaption: "4 adımlı panel akışıyla servis, ülke, operatör seçimi ve kod alımı.",
    sections: [
      {
        id: "uyelik-adimi",
        h2: "1. Üyelik Oluşturma ve Giriş",
        paragraphs: [
          "Ana sayfanın üst bölümündeki 'Kayıt Ol' butonuna tıklayarak ad-soyad, e-posta ve en az 6 karakterli şifre ile kayıt olun. Kayıt formundaki Kullanım Koşulları ve KVKK onay kutularını işaretledikten sonra hesabınız anında açılır."
        ]
      },
      {
        id: "bakiye-yukleme",
        h2: "2. Bakiye Yükleme (Min. 100 TL)",
        paragraphs: [
          "Giriş yaptığınızda üst barda bakiye alanınız görünür. '+ Bakiye Yükle' butonuna tıklayarak IBAN ile Havale/EFT bildirimi ya da kart ile ödeme seçeneklerinden biriyle minimum 100 TL yükleyebilirsiniz. 250 TL (%30) ve 500 TL (%35) yüklemelerde bonus bakiye eklenir."
        ]
      },
      {
        id: "secim-adimlari",
        h2: "3. Servis, Ülke ve Operatör Seçimi",
        paragraphs: [
          "Adım 1'de doğrulama yapacağınız uygulamayı (örneğin WhatsApp, Telegram, Instagram, Google/Gmail) seçin. Adım 2'de bölge filtreleriyle ülkenizi bulun. Adım 3'te stok durumu ve fiyatı görünen operatörlerden birini işaretleyin."
        ]
      },
      {
        id: "numara-ve-kod",
        h2: "4. Numarayı Kullanma ve SMS Kodunu Alma",
        paragraphs: [
          "'Numarayı Satın Al' butonuna tıkladığınızda numaranız ekrana gelir. Numarayı kopyalayıp uygulamaya yapıştırın. 10 dakika içinde SMS kodu otomatik olarak panele düşer. Kod gelmezse 2 dakika sonra iptal butonunu kullanabilirsiniz."
        ]
      }
    ],
    table: {
      title: "Sanal Numara Alma Aşamaları Özeti",
      headers: ["Adım", "Ekran", "İşlem"],
      rows: [
        ["1", "Servis Seçimi", "WhatsApp, Telegram, Instagram vb. seçilir"],
        ["2", "Ülke Seçimi", "60+ ülke arasından arama veya bölge filtresiyle seçilir"],
        ["3", "Operatör Seçimi", "Fiyat ve stok görülerek operatör seçilir"],
        ["4", "Numara & Kod", "Numara alınır, 10 dakikalık pencerede kod beklenir"]
      ]
    },
    steps: {
      title: "Hızlı Başlangıç Rehberi",
      items: [
        { label: "Adım 1", title: "Kayıt Olun", desc: "Üyelik bilgilerinizi girerek hesabınızı oluşturun." },
        { label: "Adım 2", title: "Bakiye Ekleyin", desc: "IBAN veya kart sekmesinden en az 100 TL yükleyin." },
        { label: "Adım 3", title: "Ülke ve Operatör Seçin", desc: "Doğrulayacağınız servis için ülke ve operatör belirleyin." },
        { label: "Adım 4", title: "Kodu Onaylayın", desc: "Gelen 6 haneli kodu uygulamaya yapıştırıp işlemi bitirin." }
      ]
    },
    faqs: [
      { q: "Sanal numara almak için telefon numarası vermem gerekiyor mu?", a: "Hayır. Onay Merkezi'ne yalnızca ad, soyad ve e-posta adresinizle kayıt olabilirsiniz." },
      { q: "Bakiyem yüklenmeden numara seçebilir miyim?", a: "Servis, ülke ve operatör fiyatlarını giriş yapmadan da görebilir; ancak satın alma butonu için giriş ve yeterli bakiye gerekir." },
      { q: "Numarayı aldıktan sonra ne kadar sürem var?", a: "SMS kodunun gelmesi için 10 dakikalık aktif süre tanımlanır." },
      { q: "Aldığım numara çalışmazsa yeniden ödeme yapar mıyım?", a: "Hayır. Kod gelmediğinde 2 dakika sonra iptal edip bakiyenizi geri alırsınız." },
      { q: "Mobil cihazdan tüm adımları yapabilir miyim?", a: "Evet, arayüz mobil ekranlar için optimize edilmiştir." }
    ],
    related: ["sanal-numara-nasil-satin-alinir", "sanal-numara-satin-al", "sanal-numara-odeme-yontemleri", "sanal-numara-iban-ile-odeme", "whatsapp-numara-alma-rehberi", "sanal-numara-sss"]
  },
  {
    slug: "sanal-numara-nasil-satin-alinir",
    menuLabel: "Numara Satın Alma Adımları",
    category: "Satın Alma & Ödeme",
    title: "Sanal Numara Satın Alma Adımları | Detaylı Kılavuz | Onay Merkezi",
    description: "Sanal numara satın alma adımları nelerdir? Sipariş öncesi hazırlık, bakiye yeterliliği, operatör tercihi ve sipariş sonrası takip rehberi.",
    h1: "Sanal Numara Satın Alma Adımları",
    lead: "Sanal numara satın alırken süreci baştan sona doğru sırayla takip etmek, hem işlem hızını artırır hem de olası hataların önüne geçer. Aşağıdaki adımlar Onay Merkezi panelindeki gerçek satın alma akışını birebir yansıtmaktadır.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "Sanal numara satın alma adımları ve sipariş akışı",
    imageCaption: "Bakiye doğrulaması, operatör seçimi ve canlı sipariş ekranı.",
    sections: [
      {
        id: "on-hazirlik",
        h2: "Satın Alma Öncesi Bakiye ve Uygulama Hazırlığı",
        paragraphs: [
          "Öncelikle doğrulama yapacağınız uygulamayı telefonunuzda hazır hale getirin. Ardından Onay Merkezi hesabınızdaki bakiyenin seçeceğiniz ülkenin fiyatını karşıladığından emin olun. Bakiye yetersizse sistem eksik tutarı otomatik hesaplayıp Bakiye Yükle ekranına yönlendirir ve yükleme sonrası kaldığınız adıma geri dönersiniz."
        ]
      },
      {
        id: "adim-1-2-3",
        h2: "Servis, Ülke ve Operatör Seçim Mantığı",
        paragraphs: [
          "Üst kısımdaki ilerleme çubuğu (1 Servis → 2 Ülke → 3 Operatör → 4 Numara) hangi aşamada olduğunuzu gösterir. Operatör adımında listelenen seçenekler arasında fiyat ve adet bilgisi yer alır; en üstte önerilen seçenek genellikle en yüksek stoklu ve en uygun fiyatlı alternatiftir."
        ]
      },
      {
        id: "satin-alma-ve-teslim",
        h2: "Sipariş Oluşturma ve Numara Teslimatı",
        paragraphs: [
          "4. adımda özet kartını görüp 'Numarayı Satın Al' butonuna tıkladığınızda bakiye düşülür ve numara hemen ekranda gösterilir. Numaranın sağındaki Kopyala düğmesi tek dokunuşla numaranızı panoya alır."
        ]
      },
      {
        id: "iptal-ve-yeni-numara",
        h2: "Sipariş Sonrası Seçenekler: Kopyala, İptal Et, Yeni Numara Al",
        paragraphs: [
          "Kod geldiğinde yeşil kutudaki 'Kodu Kopyala' düğmesini kullanın. Kod 2 dakika içinde ulaşmadıysa 'İptal Et ve İade Al' düğmesiyle bakiyenizi geri alıp 'Yeni Numara Al' butonundan operatör ekranına dönebilirsiniz."
        ]
      }
    ],
    table: {
      title: "4 Adımlı İlerleme Çubuğu Açıklamaları",
      headers: ["Adım Numarası", "Başlık", "Kullanıcı Aksiyonu"],
      rows: [
        ["1. Adım", "Servis", "8 popüler platformdan birini seçer"],
        ["2. Adım", "Ülke", "60+ ülke arasında arama veya filtreleme yapar"],
        ["3. Adım", "Operatör", "Stok ve fiyata göre sağlayıcı seçer"],
        ["4. Adım", "Numara", "Satın alır, kopyalar ve 10 dk içinde SMS kodunu görür"]
      ]
    },
    steps: {
      title: "Satın Alma İşlem Sırası",
      items: [
        { label: "Adım 1", title: "Bakiyeyi Kontrol Edin", desc: "Üst bardaki bakiyenizin seçeceğiniz ülke ücretine yettiğini görün." },
        { label: "Adım 2", title: "Servis ve Ülkeyi İşaretleyin", desc: "Örneğin WhatsApp + Türkiye (65 TL) veya Asya (15 TL) seçin." },
        { label: "Adım 3", title: "Operatörü Onaylayın", desc: "Listeden istediğiniz operatörün ok butonuna tıklayın." },
        { label: "Adım 4", title: "Satın Al ve Kodu Bekle", desc: "Numarayı kopyalayın ve geri sayım sayacı içinde kodu alın." }
      ]
    },
    faqs: [
      { q: "Satın alma butonuna bastım ama bakiyem yetersiz çıktı, seçimlerim kaybolur mu?", a: "Hayır. Sistem eksik tutarı gösterir ve bakiye yükledikten sonra kaldığınız servis/ülke/operatör seçimine devam etmenizi sağlar." },
      { q: "Numarayı satın aldıktan sonra yanlışlıkla geri tuşuna basarsam ne olur?", a: "Alt menüdeki 'Siparişler' sekmesinden son siparişinizin numarasını ve durumunu görebilirsiniz." },
      { q: "Aynı anda birden fazla numara alabilir miyim?", a: "Mevcut aktif siparişiniz sonuçlandıktan veya iptal edildikten sonra 'Yeni Numara Al' diyerek yeni işlem başlatabilirsiniz." },
      { q: "Oyun jetonu satın alma adımları aynı mı?", a: "Oyun jetonları (PUBG, Free Fire, Valorant, Mobile Legends, Steam) ana sayfada ayrı kartlar halinde sunulur ve doğrudan paket seçimiyle sipariş verilir." },
      { q: "Sipariş fişi veya kaydı tutuluyor mu?", a: "Evet, tüm siparişleriniz tarih, numara, tutar ve varsa SMS koduyla birlikte Sipariş Geçmişi ekranında saklanır." }
    ],
    related: ["sanal-numara-nasil-alinir", "sanal-numara-satin-al", "sanal-numara-odeme-yontemleri", "sms-onay-nasil-calisir", "sms-onay-iade", "numara-alirken-dikkat-edilmesi-gerekenler"]
  },
  {
    slug: "sanal-numara-odeme-yontemleri",
    menuLabel: "Ödeme Yöntemleri",
    category: "Satın Alma & Ödeme",
    title: "Sanal Numara Ödeme Yöntemleri | Kart ve IBAN | Onay Merkezi",
    description: "Onay Merkezi bakiye yükleme ve ödeme yöntemleri: IBAN ile Havale/EFT bildirimi, kartla ödeme ekranı, min. 100 TL limiti ve %30–%35 bonus.",
    h1: "Sanal Numara Ödeme Yöntemleri",
    lead: "Onay Merkezi hesabınıza bakiye yüklemek için iki farklı yöntem sunulur: IBAN üzerinden Havale/EFT bildirimi ve kart ile ödeme penceresi. Minimum yükleme tutarı 100 TL olup, yüksek tutarlı yüklemelerde %30 ve %35 oranlarında ek bakiye avantajı sağlanır.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "Sanal numara ödeme yöntemleri kart ve IBAN havale EFT ekranı",
    imageCaption: "Bakiye yükleme ekranında IBAN transfer bildirimi ve kartla ödeme seçenekleri.",
    sections: [
      {
        id: "minimum-ve-tutarlar",
        h2: "Minimum Yükleme Limiti ve Hızlı Tutar Seçenekleri",
        paragraphs: [
          "Bakiye Yükle sayfasında minimum yükleme tutarı 100 TL'dir. İsterseniz özel tutar kutusuna 100 TL ve üzeri istediğiniz rakamı yazabilir, isterseniz ₺100, ₺250, ₺500, ₺1000, ₺2000 veya ₺5000 hızlı seçim butonlarını kullanabilirsiniz."
        ]
      },
      {
        id: "iban-yontemi",
        h2: "1. IBAN ile Havale / EFT Ödemesi",
        paragraphs: [
          "Kart kullanmak istemeyen kullanıcılar için en pratik yöntem IBAN transferidir. Sayfada yer alan 'IBAN'ı Kopyala' butonuyla güncel IBAN ve hesap sahibi bilgisini kopyalayıp bankanızdan havale/EFT yaptıktan sonra 'IBAN ile Ödedim, Bildir' butonuna tıklamanız gerekir. Açılan pencerede gönderen ad soyad, gönderim saati ve tutar girilerek bildirim gönderilir."
        ]
      },
      {
        id: "kart-yontemi",
        h2: "2. Kart ile Ödeme Seçeneği",
        paragraphs: [
          "Kart ile Öde butonuna bastığınızda 256-bit SSL arayüzlü ödeme penceresi açılır. Burada kart numarası, son kullanma tarihi (AA/YY), CVV ve kart üzerindeki isim alanlarını doldurarak ödeme işlemini başlatabilirsiniz. Onaylanmayan veya banka tarafından reddedilen kartlarda tutar tahsil edilmez."
        ]
      },
      {
        id: "bonus-kampanyalari",
        h2: "Kademeli İndirim / Bonus Bakiye Sistemi",
        paragraphs: [
          "250 TL ile 499 TL arası bakiye yüklemelerinde %30, 500 TL ve üzeri yüklemelerde ise %35 oranında ek bonus bakiye tanımlanır. Tutar girişi yaptığınız anda yeşil bilgi kutusunda hesabınıza eklenecek bonus miktarını anlık olarak görebilirsiniz."
        ]
      }
    ],
    table: {
      title: "Ödeme Yöntemleri ve Bonus Özeti",
      headers: ["Yöntem", "Minimum Tutar", "Gerekli Adım"],
      rows: [
        ["IBAN (Havale / EFT / FAST)", "100 TL", "Transfer sonrası 'IBAN ile Ödedim, Bildir' formunu doldurma"],
        ["Banka / Kredi Kartı", "100 TL", "Ödeme penceresinde kart bilgilerini doğrulama"],
        ["250 TL+ Kampanyası", "250 TL", "%30 ek bonus bakiye uygulanır"],
        ["500 TL+ Kampanyası", "500 TL", "%35 ek bonus bakiye uygulanır"]
      ]
    },
    steps: {
      title: "Güvenli Bakiye Yükleme Adımları",
      items: [
        { label: "Adım 1", title: "Bakiye Yükle Ekranını Açın", desc: "Üst bardaki '+ Bakiye Yükle' veya alt menüdeki 'Bakiye' sekmesine dokunun." },
        { label: "Adım 2", title: "Tutarı Belirleyin", desc: "Minimum 100 TL olacak şekilde tutar yazın veya hızlı kutulardan seçin." },
        { label: "Adım 3", title: "Ödeme Yöntemini Seçin", desc: "Kart ile Öde veya IBAN bilgisine Havale/EFT gönderimini yapın." },
        { label: "Adım 4", title: "IBAN Bildirimini Unutmayın", desc: "Havale yaptıysanız gönderen adı, saat ve tutar bildirimini mutlaka iletin." }
      ]
    },
    faqs: [
      { q: "100 TL'nin altında bakiye yükleyebilir miyim?", a: "Hayır. Sistem minimum yükleme tutarı 100 TL olarak ayarlanmıştır; 100 TL altı girişlerde uyarı gösterilir." },
      { q: "IBAN ile ödeme yaptıktan sonra bildirim yapmazsam ne olur?", a: "Ödemenizin hangi kullanıcı hesabına ait olduğunun eşleştirilebilmesi için mutlaka 'IBAN ile Ödedim, Bildir' formunu göndermeniz gerekir." },
      { q: "Kartla ödeme reddedilirse ne yapmalıyım?", a: "Farklı bir kart deneyebilir veya doğrudan IBAN ile Havale/EFT bildirimi yöntemini kullanabilirsiniz." },
      { q: "Yüklediğim bakiyeyi yalnızca tek bir serviste mi harcayabilirim?", a: "Hayır. Yüklenen bakiye tüm SMS onay servisleri ve oyun jetonları için kullanılabilir." },
      { q: "500 TL yüklemede %35 bonus nasıl hesaplanır?", a: "500 TL'nin %35'i olan 175 TL bonus eklenerek toplam 675 TL bakiye oluşur." }
    ],
    related: ["sanal-numara-iban-ile-odeme", "sanal-numara-fiyatlari", "sanal-numara-satin-al", "sms-onay-satin-al", "sms-onay-iade", "onay-merkezi-guvenilir-mi"]
  },
  {
    slug: "sanal-numara-iban-ile-odeme",
    menuLabel: "IBAN ile Ödeme",
    category: "Satın Alma & Ödeme",
    title: "IBAN ile Bakiye Yükleme Rehberi | Havale / EFT | Onay Merkezi",
    description: "Onay Merkezi hesabınıza IBAN ile Havale, EFT veya FAST yaparak nasıl bakiye yüklenir? IBAN kopyalama ve ödeme bildirimi formu rehberi.",
    h1: "IBAN ile Bakiye Yükleme Rehberi",
    lead: "Kredi veya banka kartı bilgilerinizi paylaşmadan bakiye yüklemek istiyorsanız IBAN ile Havale/EFT/FAST yöntemi en sade seçenektir. Güncel IBAN bilgisini panelden kopyalayıp transferinizi tamamladıktan sonra ödeme bildirimi formunu doldurmanız yeterlidir.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "IBAN ile Havale EFT bakiye yükleme ve ödeme bildirimi formu",
    imageCaption: "IBAN kopyalama, transfer ve 3 alanlı hızlı ödeme bildirimi adımı.",
    sections: [
      {
        id: "iban-adim-1",
        h2: "Güncel IBAN ve Hesap Sahibi Bilgisini Kontrol Etme",
        paragraphs: [
          "Ödeme yapmadan önce mutlaka Bakiye Yükle sayfasında ekranda görünen güncel IBAN numarasını ve hesap sahibi adını kontrol edin. 'IBAN'ı Kopyala' butonunu kullanarak numarayı hatasız şekilde panoya alabilirsiniz. Eski tarihli veya başka kaynaklardan alınmış IBAN numaralarına transfer yapmayın."
        ]
      },
      {
        id: "iban-transfer",
        h2: "Havale / EFT / FAST Gönderiminde Dikkat Edilecekler",
        paragraphs: [
          "Mobil bankacılık uygulamanızdan transfer yaparken minimum tutarın 100 TL olduğunu unutmayın. FAST sistemiyle 7/24 anında transfer yapılabilse de, gönderdiğiniz tutarın bildirim formuna yazdığınız rakamla birebir aynı olması kontrol sürecini hızlandırır."
        ]
      },
      {
        id: "iban-bildirim-formu",
        h2: "'IBAN ile Ödedim, Bildir' Formunu Doldurma",
        paragraphs: [
          "Banka transferini tamamladıktan hemen sonra sitedeki turuncu 'IBAN ile Ödedim, Bildir' butonuna tıklayın. Açılan formda şu üç bilgi istenir:"
        ],
        list: [
          "Gönderen Ad Soyad: Banka hesabının sahibi olan kişinin adı ve soyadı (en az 3 karakter).",
          "Gönderim Saati: Transferi gerçekleştirdiğiniz saat ve dakika bilgisi.",
          "Gönderilen Tutar (₺): En az 100 TL olmak üzere gönderdiğiniz tam tutar."
        ]
      },
      {
        id: "onay-sureci",
        h2: "Bildirim Sonrası Bakiye Tanımlama Süreci",
        paragraphs: [
          "Bildirimi gönderdiğinizde kaydınız yönetici onay ekranına düşer. Dekont/transfer eşleşmesi doğrulandığında bakiyeniz hesabınıza eklenir ve varsa %30–%35 bonus avantajıyla birlikte tüm servislerde hemen kullanılabilir hale gelir."
        ]
      }
    ],
    table: {
      title: "IBAN Ödeme Bildirimi Alanları",
      headers: ["Form Alanı", "Nasıl Doldurulur?", "Örnek"],
      rows: [
        ["Gönderen Ad Soyad", "Transferi yapan banka hesabının sahibi", "Ahmet Yılmaz"],
        ["Gönderim Saati", "Dekonttaki saat bilgisi", "14:35"],
        ["Gönderilen Tutar", "Transfer edilen net TL tutarı (Min. 100)", "250"]
      ]
    },
    steps: {
      title: "4 Adımda IBAN ile Bakiye Yükleme",
      items: [
        { label: "Adım 1", title: "IBAN'ı Kopyalayın", desc: "Bakiye Yükle sayfasındaki güncel IBAN ve alıcı adını kopyalayın." },
        { label: "Adım 2", title: "Bankadan Transfer Yapın", desc: "En az 100 TL tutarında Havale, EFT veya FAST gönderin." },
        { label: "Adım 3", title: "Bildirim Formunu Açın", desc: "'IBAN ile Ödedim, Bildir' butonuna tıklayıp 3 alanı doldurun." },
        { label: "Adım 4", title: "Onayı Bekleyin", desc: "Kontrol tamamlandığında bakiyeniz üst barda otomatik güncellenir." }
      ]
    },
    faqs: [
      { q: "Başkasının banka hesabından IBAN ödemesi yapabilir miyim?", a: "Evet, ancak ödeme bildirim formundaki 'Gönderen Ad Soyad' kısmına mutlaka parayı gönderen hesabın sahibinin adını yazmalısınız." },
      { q: "IBAN ödemesinde minimum tutar nedir?", a: "Minimum bakiye yükleme tutarı 100 TL'dir." },
      { q: "EFT veya Havale hafta sonu da geçer mi?", a: "Bankanızın FAST limiti dahilinde 7/24 gönderim yapabilirsiniz; normal EFT işlemleri ilk iş gününde hesaba geçer." },
      { q: "Bildirim yapmayı unutursam ne olur?", a: "Sağ alttaki Canlı Destek penceresinden veya Bakiye Yükle ekranındaki bildirim formundan bilgilerinizi hemen iletebilirsiniz." },
      { q: "IBAN ile 500 TL yüklersem %35 bonus alır mıyım?", a: "Evet, kampanya koşulları dahilinde 250 TL ve 500 TL üzeri yüklemelerde bonus fırsatları geçerlidir." }
    ],
    related: ["sanal-numara-odeme-yontemleri", "sanal-numara-fiyatlari", "sanal-numara-nasil-alinir", "onay-merkezi-guvenilir-mi", "sms-onay-satin-al", "sanal-numara-sss"]
  },
  {
    slug: "sms-onay-nasil-calisir",
    menuLabel: "SMS Onay Nasıl Çalışır",
    category: "Satın Alma & Ödeme",
    title: "SMS Onay Sistemi Nasıl Çalışır? Teknik Akış | Onay Merkezi",
    description: "SMS onay sistemi arka planda nasıl çalışır? Telekom geçitleri, numara havuzu, 2 saniyelik canlı kontrol ve iade otomasyonu anlatımı.",
    h1: "SMS Onay Sistemi Nasıl Çalışır?",
    lead: "SMS onay sisteminin arka planındaki çalışma prensibini anlamak, hangi durumlarda kodun hızlı geldiğini ve neden operatör seçimi yapıldığını kavramanızı sağlar. Sistem; bulut hat havuzu, platform eşleştirme ve anlık SMS okuma adımlarından oluşur.",
    image: "/assets/images/seo-global-numaralar.jpg",
    imageAlt: "SMS onay sistemi teknik işleyiş ve bulut geçit diyagramı",
    imageCaption: "Kullanıcı siparişi, operatör yönlendirmesi ve canlı SMS yakalama süreci.",
    sections: [
      {
        id: "teknik-akıs",
        h2: "1. Numara Havuzu ve Servis Eşleştirme",
        paragraphs: [
          "Onay Merkezi panelinde her uygulama (WhatsApp, Telegram, Instagram vb.) ve her ülke farklı bir havuz parametresiyle eşleşir. Kullanıcı 'WhatsApp + Türkiye + Sanal94' seçimini yaptığında sistem ilgili operatör grubundan daha önce o serviste kullanılmamış bir hat talep eder."
        ]
      },
      {
        id: "canli-dinleme",
        h2: "2. 2 Saniyelik Canlı Polling ve Bildirim",
        paragraphs: [
          "Numara teslim edildikten sonra tarayıcıdaki sipariş ekranı arka planda her 2 saniyede bir sipariş durumunu kontrol eder. İlgili uygulama doğrulama mesajını yolladığında mesaj telekom geçidi üzerinden veritabanına yazılır ve kullanıcının ekranında yeşil kod paneli olarak belirir."
        ]
      },
      {
        id: "zaman-asimi-mekanizmasi",
        h2: "3. Zamanlayıcı, 2 Dakika Kuralı ve Otomatik İade",
        paragraphs: [
          "Her numara 600 saniye (10 dakika) boyunca aktif tutulur. İlk 120 saniye (2 dakika) SMS'in operatör ağından geçmesi için tanınan standart süredir. 120. saniyeden sonra kullanıcı isterse işlemi manuel olarak iptal edebilir; 600. saniye dolduğunda ise sistem otomatik olarak siparişi kapatıp tutarı bakiye hesabına geri ekler."
        ]
      },
      {
        id: "coklu-operator-faydası",
        h2: "4. Neden Birden Fazla Operatör Sunuluyor?",
        paragraphs: [
          "Ülkelerdeki farklı mobil operatörlerin (örneğin Sanal94, Sanal95, Sanal53, Sanal55) platformların spam filtreleriyle uyumu anlık olarak değişebilir. Çoklu operatör yapısı, bir hatta gecikme olduğunda kullanıcının alternatif bir sağlayıcıya geçmesini kolaylaştırır."
        ]
      }
    ],
    table: {
      title: "SMS Onay Teknik Zaman Çizelgesi",
      headers: ["Süre", "Sistem Olayı", "Durum"],
      rows: [
        ["0. saniye", "Numara tahsis edilir, bakiye bloke edilir", "waiting (Bekleniyor)"],
        ["Her 2 saniye", "Gelen SMS mesajı kontrol edilir", "Otomatik tarama"],
        ["120. saniye (2 dk)", "İptal et ve iade al butonu aktifleşir", "Kullanıcı iptal edebilir"],
        ["600. saniye (10 dk)", "Kod gelmediyse zaman aşımı uygulanır", "timeout + Tam bakiye iadesi"]
      ]
    },
    steps: {
      title: "Sistem Akışının 4 Aşaması",
      items: [
        { label: "Aşama 1", title: "Talep Oluşturma", desc: "Servis, ülke ve operatör parametreleri seçilerek sipariş açılır." },
        { label: "Aşama 2", title: "Numara Tahsisi", desc: "Kullanıcıya 10 dakikalık özel numara atanır." },
        { label: "Aşama 3", title: "SMS Yakalama", desc: "Platformdan gelen OTP mesajı sipariş kartına yönlendirilir." },
        { label: "Aşama 4", title: "Kapanış veya İade", desc: "Kod alındıysa sipariş tamamlanır; alınmadıysa bakiye iade edilir." }
      ]
    },
    faqs: [
      { q: "SMS onay sisteminde kod gelmeden neden 2 dakika beklemek gerekiyor?", a: "Telekom ağlarında SMS teslimatı birkaç saniyeden bir buçuk dakikaya kadar sürebildiği için gereksiz iptalleri önlemek adına 2 dakikalık pencere uygulanır." },
      { q: "Sayfayı açık tutmazsam sistem çalışmaya devam eder mi?", a: "Siparişiniz hesabınızda kayıtlı kalır, ancak anlık zamanlayıcı ve hızlı bildirim için ekranı açık tutmanız önerilir." },
      { q: "Kod geldikten sonra numara ne olur?", a: "Sipariş tamamlanır ve numara oturumu kapatılır; artık o numaraya yeni SMS yönlendirilmez." },
      { q: "Operatör isimlerindeki yüzdeler neyi ifade eder?", a: "Operatör kartlarındaki bilgiler ilgili sağlayıcının mevcut stok ve performans göstergelerini referans olarak sunar." },
      { q: "Aynı anda iki farklı sekmede sipariş açmalı mıyım?", a: "Karışıklık yaşamamak için her seferinde tek sipariş tamamlayıp ardından yeni sipariş açmanız önerilir." }
    ],
    related: ["sms-onay", "sms-kodu-alma", "sms-onay-iade", "sms-kodu-gelmiyor", "sanal-numara-nasil-satin-alinir", "sms-onay-rehberi"]
  },
  {
    slug: "numara-alirken-dikkat-edilmesi-gerekenler",
    menuLabel: "Numara Alırken Dikkat",
    category: "Satın Alma & Ödeme",
    title: "Sanal Numara Alırken Dikkat Edilmesi Gerekenler | Onay Merkezi",
    description: "Sanal numara almadan önce ve aldıktan sonra dikkat edilmesi gereken 8 kritik nokta: ülke seçimi, format, 2FA ve iade kuralları.",
    h1: "Sanal Numara Alırken Dikkat Edilmesi Gerekenler",
    lead: "Sanal numara satın alma işleminin sorunsuz sonuçlanması ve açtığınız hesabın uzun süre güvenle kullanılabilmesi için işlem öncesinde ve sonrasında bazı temel kurallara uymak büyük fark yaratır.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "Sanal numara alırken dikkat edilecek önemli kontrol maddeleri",
    imageCaption: "Doğru servis eşleşmesi, ülke kodu formatı, iade penceresi ve 2FA koruması.",
    sections: [
      {
        id: "islem-oncesi-dikkat",
        h2: "Numara Almadan Önce Kontrol Edilmesi Gerekenler",
        paragraphs: [
          "Satın alma butonuna basmadan önce şu detayları gözden geçirmeniz hatalı siparişleri önler:"
        ],
        list: [
          "Doğru Uygulama Seçimi: WhatsApp Business için standart WhatsApp yerine Business kategorisini, Gmail için Google/Gmail kategorisini seçin.",
          "Kullanım Amacı Uyumu: Banka veya resmi devlet hesabı açacaksanız tek kullanımlık sanal numara yerine kendi kişisel hattınızı kullanın.",
          "Bütçe ve Ülke Planı: Yerel görünüm şart değilse 15–20 TL bandındaki Asya seçenekleriyle daha ekonomik işlem yapabilirsiniz."
        ]
      },
      {
        id: "islem-sirasi-dikkat",
        h2: "Doğrulama Sırasında Yapılmaması Gerekenler",
        paragraphs: [
          "Numarayı aldıktan sonra uygulamaya girerken başına fazladan 0 veya tekrar ülke kodu eklemeyin. 'Beni Ara' yerine daima 'SMS Gönder' seçeneğini kullanın. Kod 2 dakika içinde gelmediğinde uygulamada art arda tuşlara basmak yerine iptal butonundan iade alıp yeni operatör deneyin."
        ]
      },
      {
        id: "islem-sonrasi-dikkat",
        h2: "Doğrulama Tamamlandıktan Sonra Yapılması Gerekenler",
        paragraphs: [
          "Hesap aktif olduğu anda kendi e-posta adresinizi kurtarma seçeneği olarak ekleyin, WhatsApp ve Telegram'da iki adımlı doğrulama PIN'i koyun ve ilk günlerde spam izlenimi verecek toplu mesajlardan kaçının."
        ]
      },
      {
        id: "odeme-guvenligi-uyari",
        h2: "Ödeme ve Bildirimlerde Dikkat",
        paragraphs: [
          "IBAN ile ödeme yaparken yalnızca sitede o an görünen güncel IBAN'ı kullanın ve gönderim sonrası bildirim formunu eksiksiz doldurun."
        ]
      }
    ],
    table: {
      title: "Yapılması ve Kaçınılması Gerekenler Tablosu",
      headers: ["Yapılmalı", "Kaçınılmalı"],
      rows: [
        ["Doğru servis kategorisini seçmek", "Farklı uygulama için başka servisten numara almak"],
        ["2FA PIN ve kurtarma e-postası eklemek", "Güvenlik ayarı yapmadan önemli hesap bırakmak"],
        ["2 dakika sonra kod yoksa iptal edip operatör değiştirmek", "Aynı numaraya art arda 5 kez SMS istemek"],
        ["Resmi uygulama sürümlerini kullanmak", "Üçüncü parti modifiye uygulamalar kullanmak"]
      ]
    },
    steps: {
      title: "Hatasız İşlem İçin 4 Kontrol Noktası",
      items: [
        { label: "Kontrol 1", title: "Servis & Ülke Uyumu", desc: "Kullanacağınız uygulamayla aynı isimdeki servisi seçin." },
        { label: "Kontrol 2", title: "Format Doğruluğu", desc: "Ülke kodunu bir kez seçin, numarayı başında 0 olmadan yapıştırın." },
        { label: "Kontrol 3", title: "Zamanlayıcı Takibi", desc: "2. dakikadan sonra iptal hakkınızı unutmayın." },
        { label: "Kontrol 4", title: "2FA & Kurtarma", desc: "Hesap açılır açılmaz ek şifre ve e-posta koruması koyun." }
      ]
    },
    faqs: [
      { q: "Yanlışlıkla farklı bir uygulama kategorisinden numara alırsam çalışır mı?", a: "Her platformun operatör yönlendirmesi farklı olduğundan yanlış kategoriden alınan numara hedef uygulamada kod almayabilir." },
      { q: "Yeni açtığım hesap neden hemen kısıtlanabilir?", a: "İlk saatlerde çok sayıda yabancı kişiye toplu mesaj atmak veya spam linki paylaşmak platformların otomatik filtresine takılabilir." },
      { q: "Aldığım numaranın süresi 10 dakikadan uzun tutulabilir mi?", a: "Hayır, aktivasyon numaraları 10 dakikalık standart doğrulama süresiyle tahsis edilir." },
      { q: "Ülke seçerken stok sayısına bakmak önemli mi?", a: "Evet, operatör ekranında yüksek stok adedi bulunan seçenekler genellikle daha güncel hatlara sahiptir." },
      { q: "Yardıma ihtiyacım olursa nereye yazabilirim?", a: "Sağ alttaki Canlı Destek penceresi üzerinden mesaj bırakabilirsiniz." }
    ],
    related: ["sanal-numara-guvenilir-mi", "whatsapp-numara-guvenligi", "sms-kodu-gelmiyor", "sms-onay-iade", "sanal-numara-kullanimi", "onay-merkezi-guvenilir-mi"]
  },
  {
    slug: "sms-onay-iade",
    menuLabel: "SMS Onay İade",
    category: "Satın Alma & Ödeme",
    title: "SMS Onay İptal ve İade Süreci | Onay Merkezi",
    description: "SMS onay kodu gelmediğinde iptal ve bakiye iadesi nasıl alınır? 2 dakika iptal kuralı, 10 dakika zaman aşımı ve kod geldikten sonraki iade koşulları.",
    h1: "SMS Onay İptal ve İade Süreci",
    lead: "SMS onay işlemlerinde her numaranın ilk denemede doğrulama kodu alacağının garantisi yoktur; platform filtreleri veya operatör yoğunluğu zaman zaman iletimi engelleyebilir. Bu nedenle Onay Merkezi'nde şeffaf bir iptal ve otomatik bakiye iadesi mekanizması uygulanır.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "SMS onay iptal etme ve bakiye iadesi süreci",
    imageCaption: "2 dakika sonrası manuel iptal ve 10 dakika zaman aşımıyla tam bakiye iadesi.",
    sections: [
      {
        id: "iade-kosullari",
        h2: "Hangi Durumlarda Tam Bakiye İadesi Yapılır?",
        paragraphs: [
          "Onay Merkezi bakiye sisteminde yalnızca SMS kodu başarıyla sipariş ekranına ulaşan işlemler ücretlendirilir. Aşağıdaki iki durumda ödenen tutarın tamamı hesap bakiyenize geri döner:"
        ],
        list: [
          "2 Dakika Sonrası Manuel İptal: Sipariş verildikten sonra 120 saniye içinde kod gelmediyse, ekranda aktifleşen 'İptal Et ve İade Al' butonuna bastığınız anda ücret bakiyenize iade edilir.",
          "10 Dakika Zaman Aşımı (Otomatik İade): 600 saniyelik geri sayım süresi dolduğunda hala SMS gelmemişse sistem siparişi otomatik olarak 'timeout' durumuna alır ve tutarı bakiyenize geri ekler."
        ]
      },
      {
        id: "iade-edilmeyen-durum",
        h2: "SMS Kodu Geldikten Sonra İade Yapılır mı?",
        paragraphs: [
          "Kullanım Koşulları uyarınca SMS doğrulama kodu sipariş ekranınıza ulaştıktan sonra numara hizmeti tamamlanmış sayılır ve bu işlem için iade yapılmaz. Bu yüzden numarayı yalnızca gerçekten kullanacağınız uygulama ekranı hazırken satın almanız önemlidir."
        ]
      },
      {
        id: "iptal-sonrasi-adim",
        h2: "İade Edilen Bakiye ile Ne Yapabilirsiniz?",
        paragraphs: [
          "İade işlemi anında hesap bakiyenize yansır ve herhangi bir bekleme olmadan yeniden numara alabilirsiniz. Aynı uygulamada farklı bir operatörü veya alternatif bir ülkeyi seçerek işleminize devam edebilirsiniz."
        ]
      },
      {
        id: "teknik-destek",
        h2: "Beklenmeyen Bir Hata Durumunda Destek",
        paragraphs: [
          "Bağlantı kesintisi veya tarayıcı hatası sebebiyle sipariş durumunuzdan emin olamazsanız Siparişler sekmesini kontrol edebilir, gerekirse Canlı Destek penceresinden ya da destek@onaymerkezi.org üzerinden destek alabilirsiniz."
        ]
      }
    ],
    table: {
      title: "SMS Onay İptal ve İade Kuralları",
      headers: ["Senaryo", "İade Durumu", "Zamanlama"],
      rows: [
        ["Kod gelmedi, 2. dakikada iptal edildi", "%100 Bakiye İadesi", "Anında hesaba yansır"],
        ["Kod gelmedi, 10 dakika süresi doldu", "%100 Bakiye İadesi", "Otomatik olarak iade edilir"],
        ["SMS kodu sipariş ekranında göründü", "İade yapılmaz", "Hizmet teslim edilmiştir"]
      ]
    },
    steps: {
      title: "İptal ve İade Alma Adımları",
      items: [
        { label: "Adım 1", title: "Sayacı Takip Edin", desc: "Sipariş kartındaki 10:00 dakikalık geri sayımı izleyin." },
        { label: "Adım 2", title: "2 Dakikanın Dolmasını Bekleyin", desc: "İlk 120 saniye sonunda iptal düğmesi gri renkten kırmızıya döner." },
        { label: "Adım 3", title: "İptal Et ve İade Al'a Tıklayın", desc: "Düğmeye bastığınız anda tutar üst bardaki bakiyenize eklenir." },
        { label: "Adım 4", title: "Yeni Operatör Seçin", desc: "'Yeni Numara Al' butonundan başka operatör veya ülke deneyin." }
      ]
    },
    faqs: [
      { q: "İptal butonuna basınca para banka kartıma mı yoksa site bakiyeme mi döner?", a: "Numara alımları site içi bakiyeden yapıldığı için iptal ve zaman aşımı iadeleri anında Onay Merkezi hesap bakiyenize geri döner." },
      { q: "2 dakika dolmadan neden iptal edemiyorum?", a: "Operatörlerden gelen SMS'in yönlendirme süresi nedeniyle ilk 2 dakika bekleme süresi olarak belirlenmiştir." },
      { q: "10 dakikalık süre dolarken sayfayı kapatmışsam iade yine yapılır mı?", a: "İade işlemi sunucu/sipariş takibine bağlıdır; ancak tarayıcı zamanlayıcısının sağlıklı tamamlanması için sipariş ekranını açık tutmanız önerilir." },
      { q: "İade sonrası yeni numara alırken ekstra ücret öder miyim?", a: "Hayır. Hesabınıza dönen bakiye ile aynı fiyattan veya farklı fiyattaki başka bir paketten devam edebilirsiniz." },
      { q: "Kullanım Koşulları'nda iade maddesi nerede yazar?", a: "Sayfa altındaki 'Kullanım Koşulları' ve 'İptal ve İade Koşulları' bağlantılarından yasal metni inceleyebilirsiniz." }
    ],
    related: ["sms-kodu-gelmiyor", "whatsapp-sms-kodu", "sms-onay-nasil-calisir", "sms-onay-siteleri", "sanal-numara-odeme-yontemleri", "onay-merkezi-guvenilir-mi"]
  },
  {
    slug: "sanal-numara-sss",
    menuLabel: "Sanal Numara SSS",
    category: "Satın Alma & Ödeme",
    title: "Sanal Numara Hakkında Sık Sorulan Sorular | Onay Merkezi",
    description: "Sanal numara ve SMS onay hakkında en çok sorulan sorular ve net yanıtları: fiyatlar, iade, güvenlik, ülke seçenekleri ve kullanım süresi.",
    h1: "Sanal Numara Hakkında Sık Sorulan Sorular",
    lead: "Sanal numara ve SMS onay servislerini kullanmaya başlamadan önce kullanıcıların en sık merak ettiği soruları tek bir sayfada topladık. Fiyatlardan iade kurallarına, gizlilikten teknik kullanıma kadar tüm yanıtları aşağıda inceleyebilirsiniz.",
    image: "/assets/images/seo-global-numaralar.jpg",
    imageAlt: "Sanal numara sık sorulan sorular ve yanıtlar rehberi",
    imageCaption: "Kullanıcıların sanal numara ve SMS onay sürecinde en çok sorduğu sorular.",
    sections: [
      {
        id: "genel-sorular",
        h2: "Genel Kullanım ve Teknik Sorular",
        paragraphs: [
          "Sanal numara kullanmak için telefonunuzda boş bir SIM kart yuvası veya eSIM desteği gerekmez. İşlemler tamamen web tarayıcısı üzerinden yürür. Alınan numara 10 dakika boyunca siparişinize atanır ve yalnızca doğrulama SMS'i almak için kullanılır; sesli arama veya düzenli mesajlaşma için kullanılamaz."
        ]
      },
      {
        id: "fiyat-ve-odeme-sorulari",
        h2: "Fiyatlandırma ve Bakiye Soruları",
        paragraphs: [
          "Onay Merkezi'nde başlangıç fiyatları 15 TL'dir (WhatsApp ve Telegram 15 TL, Google/Gmail 18 TL, Instagram ve Facebook 20 TL, Discord 22 TL, TikTok 25 TL). Türkiye (+90) WhatsApp numarası 65 TL, Business 68 TL'dir. Minimum bakiye yükleme tutarı 100 TL olup IBAN Havale/EFT bildirimi veya kartla ödeme seçenekleri sunulur."
        ]
      },
      {
        id: "iade-ve-destek-sorulari",
        h2: "Kod Gelmeme ve İade Soruları",
        paragraphs: [
          "Bir numaraya 2 dakika boyunca SMS kodu düşmezse sipariş ekranındaki iptal butonu aktif olur. İşlemi iptal ettiğinizde ya da 10 dakikalık süre dolduğunda ücret bakiyenize geri eklenir. Sorun yaşamanız halinde Canlı Destek sohbeti veya destek@onaymerkezi.org üzerinden yardım alabilirsiniz."
        ]
      },
      {
        id: "guvenlik-sorulari",
        h2: "Gizlilik ve Hesap Güvenliği Soruları",
        paragraphs: [
          "Sipariş ettiğiniz numara aktif işlem süresince yalnızca sizin hesabınıza atanır. Doğrulama tamamlandıktan sonra ilgili uygulamada İki Adımlı Doğrulama (PIN/parola) ve kurtarma e-postası eklemeniz hesabınızı uzun vadede korumanız için kritik öneme sahiptir."
        ]
      }
    ],
    table: {
      title: "Hızlı Referans SSS Özeti",
      headers: ["Soru", "Kısa Yanıt"],
      rows: [
        ["Başlangıç fiyatı nedir?", "15 TL'den başlar (Türkiye WhatsApp 65 TL)"],
        ["Minimum bakiye yükleme kaç TL?", "100 TL (250 TL+ %30, 500 TL+ %35 bonus)"],
        ["Numara ne kadar geçerli?", "10 dakika"],
        ["Kod gelmezse ne olur?", "2 dk sonra iptal veya 10 dk sonunda iade"],
        ["Kaç ülke mevcut?", "60'tan fazla ülke seçeneği"]
      ]
    },
    steps: {
      title: "Sık Sorulan Başlangıç Adımları",
      items: [
        { label: "1. Adım", title: "Kayıt ve Giriş", desc: "E-posta ile ücretsiz hesap oluşturun." },
        { label: "2. Adım", title: "Bakiye Yükleme", desc: "IBAN veya kart ile en az 100 TL ekleyin." },
        { label: "3. Adım", title: "Numara Seçimi", desc: "Servis, ülke ve operatörü belirleyin." },
        { label: "4. Adım", title: "Kod Alma", desc: "10 dakikalık sürede paneldeki kodu uygulamaya girin." }
      ]
    },
    faqs: [
      { q: "Aldığım numara süresiz benim olur mu?", a: "Hayır. SMS onay numaraları tek seferlik aktivasyon için 10 dakika boyunca geçerlidir; açtığınız hesap ise uygulamanın kurallarına uyduğunuz sürece cihazınızda açık kalır." },
      { q: "Hem bilgisayardan hem telefondan kullanabilir miyim?", a: "Evet, web arayüzü tüm cihazlarla uyumludur." },
      { q: "Oyun jetonları bölümü ne işe yarar?", a: "PUBG UC, Free Fire Elmas, Valorant VP, Mobile Legends Elmas ve Steam Cüzdan kodlarını mevcut bakiyenizle sipariş verebilmenizi sağlar." },
      { q: "IBAN bildirimi yaptıktan sonra bakiyem nasıl yüklenir?", a: "Gönderen adı, saat ve tutar bildiriminiz kontrol edildikten sonra bakiye hesabınıza tanımlanır." },
      { q: "Yasal onay metinlerini nereden okuyabilirim?", a: "Sayfa altındaki Gizlilik Politikası, Kullanım Koşulları ve KVKK Aydınlatma Metni bağlantılarından okuyabilirsiniz." }
    ],
    related: ["sanal-numara-nedir", "sanal-numara-nasil-alinir", "sms-onay-iade", "sanal-numara-odeme-yontemleri", "sms-kodu-gelmiyor", "onay-merkezi-guvenilir-mi"]
  },
  {
    slug: "onay-merkezi-guvenilir-mi",
    menuLabel: "Onay Merkezi Nedir",
    category: "Satın Alma & Ödeme",
    title: "Onay Merkezi Nedir ve Nasıl Çalışır? | Onay Merkezi",
    description: "Onay Merkezi nedir, nasıl çalışır, hangi servisleri sunar ve iade/destek süreçleri nasıl işler? Platform hakkında şeffaf bilgilendirme.",
    h1: "Onay Merkezi Nedir ve Nasıl Çalışır?",
    lead: "Onay Merkezi (onaymerkezi.org), WhatsApp, Telegram, Instagram, Google/Gmail, Facebook, TikTok ve Discord gibi dijital platformlar için 60'tan fazla ülkeden tek kullanımlık SMS onay ve sanal numara hizmeti sunan çevrimiçi bir platformdur.",
    image: "/assets/images/seo-guvenli-odeme.jpg",
    imageAlt: "Onay Merkezi platform özellikleri, iade ve destek yapısı",
    imageCaption: "Şeffaf fiyatlandırma, 2 dakika sonrası iptal hakkı, Canlı Destek ve KVKK uyumu.",
    sections: [
      {
        id: "platform-yapisi",
        h2: "Onay Merkezi Hangi Hizmetleri Sunar?",
        paragraphs: [
          "Platformun ana odağı, kullanıcıların kişisel telefon numaralarını paylaşmadan hızlı biçimde SMS doğrulaması yapabilmesidir. Ana sayfada 8 temel sosyal medya/mesajlaşma servisinin yanı sıra PUBG, Free Fire, Valorant, Mobile Legends ve Steam için Oyun Jetonları kategorisi de yer alır."
        ]
      },
      {
        id: "seffaf-kurallar",
        h2: "Şeffaflık, İade ve Müşteri Desteği İlkeleri",
        paragraphs: [
          "Kullanıcıların bir platformu değerlendirirken baktığı en önemli başlıklar şeffaflık ve ulaşılabilirliktir:"
        ],
        list: [
          "Net Fiyat Gösterimi: Her servis ve ülke için fiyatlar (15 TL'den başlayan) satın alma öncesinde ekranda açıkça yer alır.",
          "Kod Gelmezse İade: 2 dakika sonra aktifleşen iptal butonu ve 10 dakika zaman aşımı sonrası bakiye iadesi uygulanır.",
          "Çoklu Ödeme Alternatifi: Kart ile ödeme arayüzünün yanında IBAN ile Havale/EFT bildirimi seçeneği de mevcuttur.",
          "İletişim ve Yasal Metinler: Canlı Destek sohbet penceresi, destek@onaymerkezi.org adresi, Gizlilik Politikası, Kullanım Koşulları ve KVKK Aydınlatma Metni herkese açıktır."
        ]
      },
      {
        id: "siparis-ve-kontrol",
        h2: "Sipariş Geçmişi ve Kayıt Takibi",
        paragraphs: [
          "Üyelik hesabınıza giriş yaptığınızda alt menüden geçmiş siparişlerinizi, aldığınız numaraları, işlem tarihlerini ve gelen SMS kodlarını istediğiniz zaman görüntüleyebilirsiniz."
        ]
      },
      {
        id: "sorumlu-kullanim",
        h2: "Sorumlu ve Bilinçli Kullanım Çerçevesi",
        paragraphs: [
          "Onay Merkezi yalnızca yasal gizlilik, ikinci hat oluşturma ve yazılım test ihtiyaçları için hizmet verir. Herhangi bir garanti veya sınırsız kalıcılık iddiası yerine, sistemin nasıl çalıştığını ve sınırlarını açıkça paylaşmayı esas alır."
        ]
      }
    ],
    table: {
      title: "Onay Merkezi Platform Özellikleri",
      headers: ["Özellik", "Detay"],
      rows: [
        ["Web Adresi", "https://onaymerkezi.org"],
        ["Destek E-postası", "destek@onaymerkezi.org"],
        ["Ülke Kapsamı", "60+ ülke (Popüler, Avrupa, Asya, Amerika, Afrika, Orta Doğu)"],
        ["Desteklenen Servisler", "WhatsApp, WA Business, Telegram, Gmail, Instagram, Facebook, TikTok, Discord"],
        ["Ödeme Seçenekleri", "IBAN Havale/EFT bildirimi ve Kart ile ödeme (Min. 100 TL)"]
      ]
    },
    steps: {
      title: "Onay Merkezi Nasıl Çalışır?",
      items: [
        { label: "Adım 1", title: "Üye Olun", desc: "Kullanım Koşulları ve KVKK onayıyla hesabınızı açın." },
        { label: "Adım 2", title: "Bakiye Yükleyin", desc: "IBAN veya kartla en az 100 TL bakiye tanımlayın." },
        { label: "Adım 3", title: "Servis ve Ülke Seçin", desc: "İhtiyacınız olan servisi, ülkeyi ve operatörü seçin." },
        { label: "Adım 4", title: "Numara Alıp Onaylayın", desc: "10 dakikalık sürede SMS kodunu alın; kod gelmezse iade hakkını kullanın." }
      ]
    },
    faqs: [
      { q: "Onay Merkezi ile nasıl iletişime geçebilirim?", a: "Site içindeki Canlı Destek sohbet penceresinden veya destek@onaymerkezi.org e-posta adresinden ulaşabilirsiniz." },
      { q: "Kod gelmediğinde bakiyem kesin iade edilir mi?", a: "Evet. 2 dakika dolduğunda iptal butonunu kullanabilir veya 10 dakikalık sürenin bitiminde otomatik bakiye iadesi alabilirsiniz." },
      { q: "Ücretsiz deneme numarası veriliyor mu?", a: "Hayır. Ücretsiz numaralar güvenlik ve spam riski taşıdığı için yalnızca üyelere özel bakiye sistemiyle (15 TL'den başlayan fiyatlarla) tahsis yapılır." },
      { q: "Kişisel verilerim nasıl korunur?", a: "Tüm işlemler Gizlilik Politikası ve 6698 sayılı KVKK Aydınlatma Metni ilkelerine göre yürütülür." },
      { q: "Onay Merkezi'ni mobil cihazımdan kullanabilir miyim?", a: "Evet, mobil uyumlu arayüz sayesinde telefonunuzdan kolayca işlem yapabilirsiniz." }
    ],
    related: ["onay-merkezi-sanal-numara", "sanal-numara-guvenilir-mi", "sms-onay-siteleri", "sms-onay-iade", "sanal-numara-odeme-yontemleri", "sanal-numara-sss"]
  },
  {
    slug: "onay-merkezi-sanal-numara",
    menuLabel: "Onay Merkezi Sanal Numara",
    category: "Satın Alma & Ödeme",
    title: "Onay Merkezi Sanal Numara Hizmeti | 60+ Ülke | Onay Merkezi",
    description: "Onay Merkezi sanal numara hizmeti ile WhatsApp, Telegram, Instagram ve Google doğrulamaları. 60+ ülke, operatör seçenekleri ve 15 TL başlangıç.",
    h1: "Onay Merkezi Sanal Numara Hizmeti",
    lead: "Onay Merkezi sanal numara hizmeti, dijital dünyada kişisel hattınızı korumak ve birden fazla platformda hızlı SMS doğrulaması gerçekleştirmek için tasarlanmıştır. 60'tan fazla ülke ve çoklu operatör yapısıyla tek panelden pratik çözüm sunar.",
    image: "/assets/images/seo-global-numaralar.jpg",
    imageAlt: "Onay Merkezi sanal numara hizmeti 60 ülke ve çoklu platform desteği",
    imageCaption: "Tek panel üzerinden 60+ ülke, 8 ana uygulama ve operatör seçenekleri.",
    sections: [
      {
        id: "hizmet-kapsami",
        h2: "Tek Panelde 8 Popüler Uygulama ve 60+ Ülke",
        paragraphs: [
          "Onay Merkezi sanal numara servisinde WhatsApp, WhatsApp Business, Telegram, Google/Gmail, Instagram, Facebook, TikTok ve Discord uygulamaları için optimize edilmiş numara kategorileri bulunur. Ülke listesinde Türkiye (+90) başta olmak üzere ABD, İngiltere, Almanya, Fransa, Hollanda, Endonezya, Filipinler ve Hindistan gibi 60'tan fazla seçenek mevcuttur."
        ]
      },
      {
        id: "operator-secimi-farki",
        h2: "Operatör Seçimi Özelliğinin Sağladığı Esneklik",
        paragraphs: [
          "Birçok panelde yalnızca ülke seçimi yapılırken, Onay Merkezi'nde ülkeyi seçtikten sonra Sanal94, Sanal95, Sanal53 gibi operatör alternatiflerini ve stok adetlerini görerek kendiniz karar verebilirsiniz."
        ]
      },
      {
        id: "ekonomik-ve-hizli",
        h2: "Ekonomik Başlangıç ve Bonus Bakiye Seçenekleri",
        paragraphs: [
          "15 TL'den başlayan fiyatların yanında, 250 TL bakiye yüklemesine %30 ve 500 TL üzeri yüklemelere %35 ek bonus kampanyası sayesinde çoklu doğrulama ihtiyaçlarında maliyet avantajı elde edersiniz."
        ]
      },
      {
        id: "ana-sayfaya-donus",
        h2: "Hemen Başlamak İçin Ana Sayfa Adımı",
        paragraphs: [
          "Tüm rehberleri inceledikten sonra Onay Merkezi ana sayfasına geçerek kayıt olabilir, bakiyenizi yükleyip birkaç dakika içinde ilk sanal numaranızı alabilirsiniz."
        ]
      }
    ],
    table: {
      title: "Onay Merkezi Sanal Numara Hizmet Özeti",
      headers: ["Bölüm", "Özellik", "Avantaj"],
      rows: [
        ["Servis Adımı", "8 ana uygulama + arama kutusu", "Aranan servise anında erişim"],
        ["Ülke Adımı", "60+ ülke ve 6 bölge filtresi", "Türkiye, Avrupa, Asya, Amerika kolay seçilir"],
        ["Operatör Adımı", "Çoklu operatör ve stok görünümü", "Gecikme durumunda alternatif seçimi"],
        ["Numara Adımı", "2 sn'de bir canlı SMS kontrolü", "Otomatik kod gösterimi ve kopyalama"]
      ]
    },
    steps: {
      title: "Onay Merkezi'nden Sanal Numara Alma",
      items: [
        { label: "Adım 1", title: "Ana Sayfaya Gidin", desc: "Üstteki Ana Sayfa bağlantısından işlem paneline geçin." },
        { label: "Adım 2", title: "Giriş Yapın ve Bakiye Ekleyin", desc: "Hesabınıza giriş yapıp kart veya IBAN ile bakiye yükleyin." },
        { label: "Adım 3", title: "Servis ve Ülke Seçin", desc: "Doğrulama yapacağınız uygulamayı ve ülkeyi işaretleyin." },
        { label: "Adım 4", title: "Numarayı Alın", desc: "Operatör seçiminin ardından numarayı kopyalayıp SMS kodunu alın." }
      ]
    },
    faqs: [
      { q: "Onay Merkezi üzerinden hangi ülkelerin numaraları alınabilir?", a: "Türkiye, ABD, İngiltere, Almanya, Fransa, Hollanda, Endonezya, Filipinler ve Hindistan dahil 60'tan fazla ülke desteklenir." },
      { q: "WhatsApp ve Telegram dışında hangi uygulamalar var?", a: "WhatsApp Business, Google/Gmail, Instagram, Facebook, TikTok ve Discord doğrudan ana servis listesinde yer alır." },
      { q: "Bakiye yüklemede indirim kampanyası var mı?", a: "Evet, 250 TL yüklemeye %30, 500 TL ve üzeri yüklemelere %35 bonus bakiye uygulanmaktadır." },
      { q: "Kod gelmezse ne kadar sürede iade alırım?", a: "2 dakika sonra iptal butonunu kullanabilir veya 10 dakikalık sürenin sonunda otomatik bakiye iadesi alabilirsiniz." },
      { q: "Onay Merkezi'nde destek ekibine nasıl ulaşılır?", a: "Canlı Destek sohbet penceresinden veya destek@onaymerkezi.org e-posta adresinden ulaşabilirsiniz." }
    ],
    related: ["onay-merkezi-guvenilir-mi", "whatsapp-sanal-numara", "sanal-numara-nedir", "sanal-numara-fiyatlari", "sanal-numara-nasil-alinir", "sanal-numara-sss"]
  }
];
