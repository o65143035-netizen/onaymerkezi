import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, "..");

const SEO_SLUGS = [
  "whatsapp-sanal-numara",
  "whatsapp-sanal-numara-satin-al",
  "whatsapp-sms-onay",
  "whatsapp-ikinci-numara",
  "whatsapp-business-sanal-numara",
  "whatsapp-numara-dogrulama",
  "whatsapp-sms-kodu",
  "whatsapp-sanal-numara-fiyatlari",
  "whatsapp-numara-alma-rehberi",
  "whatsapp-numara-guvenligi",
  "sanal-numara-nedir",
  "sanal-numara-satin-al",
  "sanal-numara-fiyatlari",
  "ucuz-sanal-numara",
  "gecici-numara",
  "telefon-numarasi-satin-al",
  "yurtdisi-sanal-numara",
  "turkiye-sanal-numara",
  "sanal-numara-kullanimi",
  "sanal-numara-guvenilir-mi",
  "sms-onay",
  "sms-onay-satin-al",
  "sms-onay-siteleri",
  "sms-onay-fiyatlari",
  "sms-kodu-alma",
  "mobil-onay",
  "sms-dogrulama",
  "sms-onay-guvenligi",
  "sms-kodu-gelmiyor",
  "sms-onay-rehberi",
  "telegram-sanal-numara",
  "telegram-sms-onay",
  "instagram-sms-onay",
  "google-sms-onay",
  "facebook-sms-onay",
  "tiktok-sms-onay",
  "discord-sms-onay",
  "x-sms-onay",
  "tinder-sms-onay",
  "gmail-sms-onay",
  "sanal-numara-nasil-alinir",
  "sanal-numara-nasil-satin-alinir",
  "sanal-numara-odeme-yontemleri",
  "sanal-numara-iban-ile-odeme",
  "sms-onay-nasil-calisir",
  "numara-alirken-dikkat-edilmesi-gerekenler",
  "sms-onay-iade",
  "sanal-numara-sss",
  "onay-merkezi-guvenilir-mi",
  "onay-merkezi-sanal-numara",
  "en-populer-sanal-numara-siteleri",
  "turkiyenin-sanal-numara-saglayicilari",
  "dunyanin-en-bilinen-sms-onay-siteleri",
  "onay-merkezi-rakipleri-ve-alternatifleri",
  "smsvar-incelemesi",
  "smmsim-incelemesi",
  "sms-prime-incelemesi",
  "smsvar-alternatifleri",
  "smmsim-alternatifleri",
  "onay-merkezi-karsilastirmasi",
  "5sim-incelemesi",
  "sms-man-incelemesi",
  "smspool-incelemesi",
  "smspva-incelemesi",
  "sms-activate-incelemesi",
  "textverified-incelemesi",
  "herosms-incelemesi",
  "onlinesim-incelemesi",
  "quackr-incelemesi",
  "hushed-incelemesi",
  "5sim-alternatifleri",
  "sms-man-alternatifleri",
  "smspool-alternatifleri",
  "smspva-alternatifleri",
  "sms-activate-alternatifleri",
  "textverified-alternatifleri",
  "herosms-alternatifleri",
  "onlinesim-alternatifleri",
  "quackr-alternatifleri",
  "sms-onay-siteleri-karsilastirmasi",
  "sanal-numara-fiyat-karsilastirmasi",
  "en-uygun-sanal-numara-saglayicilari",
  "ucuz-sms-onay-platformlari",
  "turk-numarasi-sunan-platformlar",
  "yabanci-numara-sunan-platformlar",
  "whatsapp-numara-saglayicilari-karsilastirmasi",
  "telegram-numara-saglayicilari-karsilastirmasi",
  "instagram-sms-onay-saglayicilari",
  "google-sms-onay-saglayicilari",
  "uzun-sureli-sanal-numara-saglayicilari",
  "tek-kullanimlik-numara-platformlari",
  "sanal-numara-servislerinde-iade-politikalari",
  "sanal-numara-servislerinde-odeme-yontemleri",
  "sms-onay-servislerinde-api-karsilastirmasi",
  "sanal-numara-servislerinde-guvenlik-karsilastirmasi",
  "gercek-sim-ve-voip-numara-karsilastirmasi",
  "sms-gelmeme-oranlari-ve-servis-guvenilirligi",
  "sanal-numara-satin-alirken-saglayici-secimi",
  "uluslararasi-sanal-numara-platformlari",
  "2026-sanal-numara-platformlari-rehberi",
];

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escapePreCode(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function unescapePreCode(str) {
  return str
    .replace(/&gt;/g, ">")
    .replace(/&lt;/g, "<")
    .replace(/&amp;/g, "&");
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const GROUPS = [
  {
    id: "core",
    title: "Ana Sayfa, Sunucu, Vercel ve Yapılandırma",
    files: [
      "index.html",
      "vercel.json",
      "server.ts",
      "package.json",
      "tsconfig.json",
      "metadata.json",
      "vite.config.ts",
      ".env.example",
      ".gitignore",
    ],
  },
  {
    id: "assets-seo",
    title: "CSS, Sitemap, Robots ve Src Dosyaları",
    files: [
      "public/assets/seo-pages.css",
      "public/sitemap.xml",
      "public/robots.txt",
      "src/App.tsx",
      "src/main.tsx",
      "src/index.css",
    ],
  },
  {
    id: "modules",
    title: "10 Adet SEO Veri Modülü ve Yardımcı Scriptler",
    files: [
      "scripts/seo-data-whatsapp.mjs",
      "scripts/seo-data-sanal.mjs",
      "scripts/seo-data-sms.mjs",
      "scripts/seo-data-apps.mjs",
      "scripts/seo-data-payment.mjs",
      "scripts/seo-data-comp-overview.mjs",
      "scripts/seo-data-comp-global.mjs",
      "scripts/seo-data-comp-alternatives.mjs",
      "scripts/seo-data-comp-platforms.mjs",
      "scripts/seo-data-comp-technical.mjs",
      "scripts/generate-seo-pages.mjs",
      "scripts/verify-seo-project.mjs",
      "scripts/build-bundle-html.mjs",
    ],
  },
  {
    id: "seo-pages",
    title: "100 Adet Statik SEO HTML Sayfası",
    files: SEO_SLUGS.map((slug) => `public/${slug}/index.html`),
  },
];

const allEntries = [];
let globalIndex = 0;
let totalRawBytes = 0;

for (const group of GROUPS) {
  for (const relPath of group.files) {
    const absPath = path.join(ROOT_DIR, relPath);
    if (!fs.existsSync(absPath)) {
      throw new Error(`Eksik proje dosyası: ${relPath}`);
    }
    const content = fs.readFileSync(absPath, "utf8");
    const bytes = Buffer.byteLength(content, "utf8");
    const lines = content.split("\n").length;
    globalIndex += 1;
    totalRawBytes += bytes;
    allEntries.push({
      index: globalIndex,
      id: `file-${globalIndex}`,
      groupId: group.id,
      groupTitle: group.title,
      relPath,
      content,
      bytes,
      lines,
    });
  }
}

const navHtml = GROUPS.map((group) => {
  const items = allEntries.filter((e) => e.groupId === group.id);
  const linksHtml = items
    .map(
      (item) => `<a class="nav-link" href="#${item.id}" data-search="${escapeHtml(item.relPath.toLowerCase())}">
        <span class="nav-num">${String(item.index).padStart(2, "0")}</span>
        <span class="nav-name">${escapeHtml(item.relPath)}</span>
        <span class="nav-size">${escapeHtml(formatBytes(item.bytes))}</span>
      </a>`
    )
    .join("\n");
  return `<div class="nav-group" data-group="${group.id}">
      <div class="nav-group-title">${escapeHtml(group.title)} (${items.length})</div>
      ${linksHtml}
    </div>`;
}).join("\n");

const selectOptionsHtml = GROUPS.map((group) => {
  const items = allEntries.filter((e) => e.groupId === group.id);
  const opts = items
    .map(
      (item) =>
        `<option value="#${item.id}">${String(item.index).padStart(2, "0")}. ${escapeHtml(item.relPath)} (${escapeHtml(formatBytes(item.bytes))})</option>`
    )
    .join("");
  return `<optgroup label="${escapeHtml(group.title)}">${opts}</optgroup>`;
}).join("");

const sectionsHtml = allEntries
  .map((item) => {
    const escapedCode = escapePreCode(item.content);
    return `<section class="file-card" id="${item.id}" data-file-card="${escapeHtml(item.relPath.toLowerCase())}">
      <header class="file-header">
        <div class="file-meta">
          <span class="file-index">#${String(item.index).padStart(2, "0")}</span>
          <h2 class="file-title">${escapeHtml(item.relPath)}</h2>
          <span class="file-stats">${escapeHtml(item.groupTitle)} • ${item.lines} satır • ${escapeHtml(formatBytes(item.bytes))}</span>
        </div>
        <div class="file-actions">
          <button type="button" class="btn-secondary btn-copy-one" data-copy-target="${item.id}">Bu Dosyayı Kopyala</button>
          <button type="button" class="btn-secondary" data-download-target="${item.id}">İndir</button>
          <button type="button" class="btn-ghost btn-toggle" data-toggle-target="${item.id}" aria-expanded="true">Daralt</button>
        </div>
      </header>
      <div class="code-wrap" id="wrap-${item.id}">
        <pre class="code-pre"><code class="code-block" data-file-path="${escapeHtml(item.relPath)}" id="code-${item.id}">${escapedCode}</code></pre>
      </div>
    </section>`;
  })
  .join("\n\n");

const builtAt = new Date().toISOString();

const bundleHtml = `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="robots" content="noindex, nofollow" />
  <title>Onay Merkezi — Tüm Proje Kaynak Kodları (${allEntries.length} Dosya)</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; }
    :root {
      --bg: #f8fafc;
      --surface: #ffffff;
      --surface-alt: #f1f5f9;
      --border: #e2e8f0;
      --text: #0f172a;
      --muted: #475569;
      --primary: #2563eb;
      --primary-hover: #1d4ed8;
      --code-bg: #0f172a;
      --code-fg: #e2e8f0;
      --success: #15803d;
    }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.5;
    }
    .topbar {
      position: sticky;
      top: 0;
      z-index: 50;
      background: rgba(255, 255, 255, 0.96);
      backdrop-filter: blur(8px);
      border-bottom: 1px solid var(--border);
      padding: 12px 20px;
    }
    .topbar-inner {
      max-width: 1520px;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .brand {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .brand h1 {
      margin: 0;
      font-size: 1.125rem;
      font-weight: 700;
      color: var(--text);
    }
    .brand p {
      margin: 0;
      font-size: 0.8125rem;
      color: var(--muted);
    }
    .topbar-actions {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 10px;
    }
    .btn-primary {
      appearance: none;
      border: 0;
      background: var(--primary);
      color: #ffffff;
      font-weight: 700;
      font-size: 0.9375rem;
      padding: 11px 18px;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.15s ease;
    }
    .btn-primary:hover { background: var(--primary-hover); }
    .btn-secondary {
      appearance: none;
      border: 1px solid var(--border);
      background: var(--surface);
      color: var(--text);
      font-weight: 600;
      font-size: 0.8125rem;
      padding: 7px 12px;
      border-radius: 6px;
      cursor: pointer;
    }
    .btn-secondary:hover { background: var(--surface-alt); }
    .btn-ghost {
      appearance: none;
      border: 1px solid transparent;
      background: transparent;
      color: var(--muted);
      font-weight: 600;
      font-size: 0.8125rem;
      padding: 7px 10px;
      border-radius: 6px;
      cursor: pointer;
    }
    .btn-ghost:hover { background: var(--surface-alt); color: var(--text); }
    .copy-status {
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--success);
      min-height: 1.25em;
    }
    .quick-jump {
      display: none;
      width: 100%;
      padding: 9px 10px;
      border: 1px solid var(--border);
      border-radius: 8px;
      background: var(--surface);
      color: var(--text);
      font-size: 0.875rem;
    }
    .layout {
      max-width: 1520px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 320px minmax(0, 1fr);
      gap: 20px;
      padding: 20px;
      align-items: start;
    }
    .sidebar {
      position: sticky;
      top: 84px;
      max-height: calc(100vh - 104px);
      display: flex;
      flex-direction: column;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 10px;
      overflow: hidden;
    }
    .sidebar-search-wrap {
      padding: 12px;
      border-bottom: 1px solid var(--border);
      background: var(--surface);
    }
    .sidebar-search {
      width: 100%;
      padding: 9px 12px;
      border: 1px solid var(--border);
      border-radius: 6px;
      font-size: 0.875rem;
      color: var(--text);
      background: var(--bg);
    }
    .sidebar-nav {
      overflow-y: auto;
      padding: 10px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .nav-group-title {
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      color: var(--muted);
      padding: 4px 8px;
    }
    .nav-link {
      display: grid;
      grid-template-columns: 24px minmax(0, 1fr) auto;
      align-items: center;
      gap: 6px;
      padding: 6px 8px;
      border-radius: 6px;
      text-decoration: none;
      color: var(--text);
      font-size: 0.8125rem;
    }
    .nav-link:hover {
      background: var(--surface-alt);
      color: var(--primary);
    }
    .nav-num {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 0.75rem;
      color: var(--muted);
    }
    .nav-name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .nav-size {
      font-size: 0.72rem;
      color: var(--muted);
      white-space: nowrap;
    }
    .content {
      display: flex;
      flex-direction: column;
      gap: 20px;
      min-width: 0;
    }
    .file-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 10px;
      overflow: hidden;
      scroll-margin-top: 88px;
    }
    .file-header {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 14px 16px;
      background: var(--surface-alt);
      border-bottom: 1px solid var(--border);
    }
    .file-meta {
      display: flex;
      flex-wrap: wrap;
      align-items: baseline;
      gap: 10px;
      min-width: 0;
    }
    .file-index {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 0.8125rem;
      font-weight: 700;
      color: var(--primary);
    }
    .file-title {
      margin: 0;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 0.95rem;
      font-weight: 700;
      color: var(--text);
      word-break: break-all;
    }
    .file-stats {
      font-size: 0.78rem;
      color: var(--muted);
    }
    .file-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .code-wrap.is-collapsed {
      display: none;
    }
    .code-pre {
      margin: 0;
      padding: 16px;
      background: var(--code-bg);
      color: var(--code-fg);
      overflow-x: auto;
      max-height: 620px;
      overflow-y: auto;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
      font-size: 0.8125rem;
      line-height: 1.55;
      tab-size: 2;
    }
    .code-block {
      display: block;
      white-space: pre;
    }
    .back-top {
      position: fixed;
      right: 20px;
      bottom: 20px;
      z-index: 40;
      background: var(--text);
      color: #ffffff;
      border: 0;
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 0.8125rem;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(15, 23, 42, 0.2);
    }
    .hidden-by-filter { display: none !important; }
    @media (max-width: 980px) {
      .layout {
        grid-template-columns: 1fr;
        padding: 12px;
      }
      .sidebar {
        display: none;
      }
      .quick-jump {
        display: block;
      }
    }
  </style>
</head>
<body>
  <header class="topbar" id="top">
    <div class="topbar-inner">
      <div class="brand">
        <h1>Onay Merkezi — Tüm Proje Kaynak Kodları</h1>
        <p>${allEntries.length} dosya • Toplam ham kaynak kodu: ${formatBytes(totalRawBytes)} • UTF-8 Bağımsız Tek HTML Paketi (${builtAt.slice(0, 10)})</p>
      </div>
      <div class="topbar-actions">
        <button type="button" class="btn-primary" id="copyAllBtn">TÜM KODLARI KOPYALA (${allEntries.length} Dosya)</button>
        <button type="button" class="btn-secondary" id="downloadSelfBtn">HTML İndir</button>
        <button type="button" class="btn-secondary" id="downloadTxtBtn">Düz Metin (.txt) İndir</button>
        <span class="copy-status" id="copyStatus" aria-live="polite"></span>
      </div>
      <select class="quick-jump" id="quickJumpSelect" aria-label="Dosyaya git">
        <option value="">Dosya seçin ve doğrudan gidin (${allEntries.length} dosya)...</option>
        ${selectOptionsHtml}
      </select>
    </div>
  </header>

  <div class="layout">
    <aside class="sidebar" aria-label="Dosya gezgini">
      <div class="sidebar-search-wrap">
        <input type="search" class="sidebar-search" id="fileSearchInput" placeholder="Dosya ara (ör: whatsapp, server, sitemap)..." />
      </div>
      <nav class="sidebar-nav" id="sidebarNav">
        ${navHtml}
      </nav>
    </aside>

    <main class="content" id="mainContent">
      ${sectionsHtml}
    </main>
  </div>

  <button type="button" class="back-top" id="backTopBtn">Yukarı Çık</button>

  <script>
    (function () {
      const copyStatus = document.getElementById("copyStatus");
      const copyAllBtn = document.getElementById("copyAllBtn");
      const downloadSelfBtn = document.getElementById("downloadSelfBtn");
      const quickJumpSelect = document.getElementById("quickJumpSelect");
      const fileSearchInput = document.getElementById("fileSearchInput");
      const backTopBtn = document.getElementById("backTopBtn");

      function showStatus(message) {
        copyStatus.textContent = message;
        clearTimeout(showStatus._timer);
        showStatus._timer = setTimeout(function () {
          copyStatus.textContent = "";
        }, 5000);
      }

      async function copyTextSafe(text) {
        if (navigator.clipboard && window.isSecureContext) {
          try {
            await navigator.clipboard.writeText(text);
            return true;
          } catch (_err) {
            // Fallback below
          }
        }
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.setAttribute("readonly", "");
        textarea.style.position = "fixed";
        textarea.style.top = "-9999px";
        textarea.style.left = "-9999px";
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        let ok = false;
        try {
          ok = document.execCommand("copy");
        } catch (_err) {
          ok = false;
        }
        document.body.removeChild(textarea);
        return ok;
      }

      copyAllBtn.addEventListener("click", async function () {
        const blocks = document.querySelectorAll("code.code-block[data-file-path]");
        const parts = [];
        for (let i = 0; i < blocks.length; i++) {
          const el = blocks[i];
          const filePath = el.getAttribute("data-file-path") || "";
          const content = el.textContent || "";
          parts.push(
            "================================================================================\\n" +
            "DOSYA (" + (i + 1) + "/" + blocks.length + "): " + filePath + "\\n" +
            "================================================================================\\n" +
            content +
            (content.endsWith("\\n") ? "" : "\\n")
          );
        }
        const fullBundleText = parts.join("\\n");
        const copied = await copyTextSafe(fullBundleText);
        if (copied) {
          const mb = (new Blob([fullBundleText]).size / (1024 * 1024)).toFixed(2);
          showStatus("✓ Tüm " + blocks.length + " dosya panoya kopyalandı (" + mb + " MB)");
        } else {
          showStatus("Kopyalama tarayıcı tarafından engellendi; dosyayı indirip açarak deneyin.");
        }
      });

      document.addEventListener("click", async function (e) {
        const copyBtn = e.target.closest("[data-copy-target]");
        if (copyBtn) {
          const targetId = copyBtn.getAttribute("data-copy-target");
          const codeEl = document.getElementById("code-" + targetId);
          if (!codeEl) return;
          const ok = await copyTextSafe(codeEl.textContent || "");
          if (ok) {
            const orig = copyBtn.textContent;
            copyBtn.textContent = "Kopyalandı ✓";
            showStatus("✓ " + (codeEl.getAttribute("data-file-path") || "") + " kopyalandı");
            setTimeout(function () {
              copyBtn.textContent = orig;
            }, 1800);
          }
          return;
        }

        const downloadBtn = e.target.closest("[data-download-target]");
        if (downloadBtn) {
          const targetId = downloadBtn.getAttribute("data-download-target");
          const codeEl = document.getElementById("code-" + targetId);
          if (!codeEl) return;
          const relPath = codeEl.getAttribute("data-file-path") || "dosya.txt";
          const fileName = relPath.split("/").pop() || "dosya.txt";
          const blob = new Blob([codeEl.textContent || ""], { type: "text/plain;charset=utf-8" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          showStatus("✓ " + relPath + " indiriliyor (" + fileName + ")");
          setTimeout(function () {
            URL.revokeObjectURL(url);
          }, 1000);
          return;
        }

        const toggleBtn = e.target.closest("[data-toggle-target]");
        if (toggleBtn) {
          const targetId = toggleBtn.getAttribute("data-toggle-target");
          const wrapEl = document.getElementById("wrap-" + targetId);
          if (!wrapEl) return;
          const collapsed = wrapEl.classList.toggle("is-collapsed");
          toggleBtn.textContent = collapsed ? "Genişlet" : "Daralt";
          toggleBtn.setAttribute("aria-expanded", collapsed ? "false" : "true");
        }
      });

      quickJumpSelect.addEventListener("change", function () {
        const hash = quickJumpSelect.value;
        if (!hash) return;
        const target = document.querySelector(hash);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      });

      fileSearchInput.addEventListener("input", function () {
        const q = fileSearchInput.value.trim().toLowerCase();
        const links = document.querySelectorAll(".nav-link[data-search]");
        links.forEach(function (link) {
          const pathText = link.getAttribute("data-search") || "";
          if (!q || pathText.indexOf(q) !== -1) {
            link.classList.remove("hidden-by-filter");
          } else {
            link.classList.add("hidden-by-filter");
          }
        });
        const groups = document.querySelectorAll(".nav-group");
        groups.forEach(function (group) {
          const visible = group.querySelectorAll(".nav-link:not(.hidden-by-filter)").length;
          if (visible === 0) {
            group.classList.add("hidden-by-filter");
          } else {
            group.classList.remove("hidden-by-filter");
          }
        });
      });

      downloadSelfBtn.addEventListener("click", function () {
        const htmlDoc = "<!DOCTYPE html>\\n" + document.documentElement.outerHTML;
        const blob = new Blob([htmlDoc], { type: "text/html;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "onay-merkezi-tum-kodlar.html";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () {
          URL.revokeObjectURL(url);
        }, 1000);
      });

      const downloadTxtBtn = document.getElementById("downloadTxtBtn");
      downloadTxtBtn.addEventListener("click", function () {
        const blocks = document.querySelectorAll("code.code-block[data-file-path]");
        const parts = [];
        for (let i = 0; i < blocks.length; i++) {
          const el = blocks[i];
          const filePath = el.getAttribute("data-file-path") || "";
          const content = el.textContent || "";
          parts.push(
            "================================================================================\\n" +
            "DOSYA (" + (i + 1) + "/" + blocks.length + "): " + filePath + "\\n" +
            "================================================================================\\n" +
            content +
            (content.endsWith("\\n") ? "" : "\\n")
          );
        }
        const blob = new Blob([parts.join("\\n")], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "onay-merkezi-tum-kodlar.txt";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        showStatus("✓ Düz metin (.txt) dosyası indiriliyor (" + blocks.length + " dosya)");
        setTimeout(function () {
          URL.revokeObjectURL(url);
        }, 1000);
      });

      backTopBtn.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    })();
  </script>
</body>
</html>
`;

const outDir = path.join(ROOT_DIR, "public", "downloads");
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, "onay-merkezi-tum-kodlar.html");
fs.writeFileSync(outPath, bundleHtml, "utf8");

// Generate pure UTF-8 plain text single file (onay-merkezi-tum-kodlar.txt)
const txtParts = allEntries.map((entry) => {
  const trailing = entry.content.endsWith("\n") ? "" : "\n";
  return (
    "================================================================================\n" +
    `DOSYA (${entry.index}/${allEntries.length}): ${entry.relPath}\n` +
    "================================================================================\n" +
    entry.content +
    trailing
  );
});
const outTxtPath = path.join(outDir, "onay-merkezi-tum-kodlar.txt");
fs.writeFileSync(outTxtPath, txtParts.join("\n"), "utf8");

// Self-verify every single embedded <code> block decodes 100% identically back to the original file
const written = fs.readFileSync(outPath, "utf8");
const blockRegex = /<code class="code-block" data-file-path="([^"]+)" id="[^"]+">([\s\S]*?)<\/code>/g;
const decodedMap = new Map();
let match;
while ((match = blockRegex.exec(written)) !== null) {
  decodedMap.set(match[1], unescapePreCode(match[2]));
}

if (decodedMap.size !== allEntries.length) {
  throw new Error(`Beklenen dosya sayısı ${allEntries.length}, bulunan ${decodedMap.size}`);
}

for (const entry of allEntries) {
  const decoded = decodedMap.get(entry.relPath);
  if (decoded !== entry.content) {
    throw new Error(`İçerik eşleşmedi: ${entry.relPath}`);
  }
}

console.log(`SUCCESS HTML: ${outPath} (${formatBytes(Buffer.byteLength(written, "utf8"))})`);
console.log(`SUCCESS TXT : ${outTxtPath} (${formatBytes(fs.statSync(outTxtPath).size)})`);
console.log(`Embedded files verified 1:1 (${allEntries.length} files)`);
