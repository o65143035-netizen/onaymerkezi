import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, "..");
const PUBLIC_DIR = path.join(ROOT_DIR, "public");

const EXPECTED_SLUGS = [
  "whatsapp-sanal-numara",
  "whatsapp-sanal-numara-satin-al",
  "whatsapp-sms-onay",
  "whatsapp-ikinci-numara",
  "whatsapp-business-sanal-numara",
  "whatsapp-numara-dogrulama",
  "whatsapp-sms-kodu",
  "whatsapp-sanal-numara-fiyatlari",
  "whatsapp-numara-alma-rehberi",
  "whatsapp-numara-guvenligi",
  "sanal-numara-nedir",
  "sanal-numara-satin-al",
  "sanal-numara-fiyatlari",
  "ucuz-sanal-numara",
  "gecici-numara",
  "telefon-numarasi-satin-al",
  "yurtdisi-sanal-numara",
  "turkiye-sanal-numara",
  "sanal-numara-kullanimi",
  "sanal-numara-guvenilir-mi",
  "sms-onay",
  "sms-onay-satin-al",
  "sms-onay-siteleri",
  "sms-onay-fiyatlari",
  "sms-kodu-alma",
  "mobil-onay",
  "sms-dogrulama",
  "sms-onay-guvenligi",
  "sms-kodu-gelmiyor",
  "sms-onay-rehberi",
  "telegram-sanal-numara",
  "telegram-sms-onay",
  "instagram-sms-onay",
  "google-sms-onay",
  "facebook-sms-onay",
  "tiktok-sms-onay",
  "discord-sms-onay",
  "x-sms-onay",
  "tinder-sms-onay",
  "gmail-sms-onay",
  "sanal-numara-nasil-alinir",
  "sanal-numara-nasil-satin-alinir",
  "sanal-numara-odeme-yontemleri",
  "sanal-numara-iban-ile-odeme",
  "sms-onay-nasil-calisir",
  "numara-alirken-dikkat-edilmesi-gerekenler",
  "sms-onay-iade",
  "sanal-numara-sss",
  "onay-merkezi-guvenilir-mi",
  "onay-merkezi-sanal-numara",
  "en-populer-sanal-numara-siteleri",
  "turkiyenin-sanal-numara-saglayicilari",
  "dunyanin-en-bilinen-sms-onay-siteleri",
  "onay-merkezi-rakipleri-ve-alternatifleri",
  "smsvar-incelemesi",
  "smmsim-incelemesi",
  "sms-prime-incelemesi",
  "smsvar-alternatifleri",
  "smmsim-alternatifleri",
  "onay-merkezi-karsilastirmasi",
  "5sim-incelemesi",
  "sms-man-incelemesi",
  "smspool-incelemesi",
  "smspva-incelemesi",
  "sms-activate-incelemesi",
  "textverified-incelemesi",
  "herosms-incelemesi",
  "onlinesim-incelemesi",
  "quackr-incelemesi",
  "hushed-incelemesi",
  "5sim-alternatifleri",
  "sms-man-alternatifleri",
  "smspool-alternatifleri",
  "smspva-alternatifleri",
  "sms-activate-alternatifleri",
  "textverified-alternatifleri",
  "herosms-alternatifleri",
  "onlinesim-alternatifleri",
  "quackr-alternatifleri",
  "sms-onay-siteleri-karsilastirmasi",
  "sanal-numara-fiyat-karsilastirmasi",
  "en-uygun-sanal-numara-saglayicilari",
  "ucuz-sms-onay-platformlari",
  "turk-numarasi-sunan-platformlar",
  "yabanci-numara-sunan-platformlar",
  "whatsapp-numara-saglayicilari-karsilastirmasi",
  "telegram-numara-saglayicilari-karsilastirmasi",
  "instagram-sms-onay-saglayicilari",
  "google-sms-onay-saglayicilari",
  "uzun-sureli-sanal-numara-saglayicilari",
  "tek-kullanimlik-numara-platformlari",
  "sanal-numara-servislerinde-iade-politikalari",
  "sanal-numara-servislerinde-odeme-yontemleri",
  "sms-onay-servislerinde-api-karsilastirmasi",
  "sanal-numara-servislerinde-guvenlik-karsilastirmasi",
  "gercek-sim-ve-voip-numara-karsilastirmasi",
  "sms-gelmeme-oranlari-ve-servis-guvenilirligi",
  "sanal-numara-satin-alirken-saglayici-secimi",
  "uluslararasi-sanal-numara-platformlari",
  "2026-sanal-numara-platformlari-rehberi",
];

const MOJIBAKE_PATTERNS = [/Ã[¼¶§ÄÅ]/, /Ä[±Ÿ°]/, /Å[žŸ]/, /\uFFFD/];

const titles = new Set();
const descriptions = new Set();
const canonicals = new Set();
const h1s = new Set();
const errors = [];

for (const slug of EXPECTED_SLUGS) {
  const filePath = path.join(PUBLIC_DIR, slug, "index.html");
  if (!fs.existsSync(filePath)) {
    errors.push(`Missing file: ${filePath}`);
    continue;
  }
  const html = fs.readFileSync(filePath, "utf8");

  if (!html.includes('<meta charset="UTF-8">')) {
    errors.push(`Missing UTF-8 charset in ${slug}`);
  }
  for (const pat of MOJIBAKE_PATTERNS) {
    if (pat.test(html)) {
      errors.push(`Mojibake pattern ${pat} found in ${slug}`);
    }
  }
  if (!/[çğıİöşü]/.test(html)) {
    errors.push(`No Turkish characters found in ${slug}`);
  }

  const titleMatch = html.match(/<title>([^<]+)<\/title>/);
  const descMatch = html.match(/<meta name="description" content="([^"]+)">/);
  const canonMatch = html.match(/<link rel="canonical" href="([^"]+)">/);
  const h1Matches = html.match(/<h1[^>]*>([^<]+)<\/h1>/g) || [];
  const jsonLdMatch = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);

  if (!titleMatch) errors.push(`Missing title in ${slug}`);
  else {
    if (titles.has(titleMatch[1])) errors.push(`Duplicate title in ${slug}: ${titleMatch[1]}`);
    titles.add(titleMatch[1]);
  }

  if (!descMatch) errors.push(`Missing description in ${slug}`);
  else {
    if (descriptions.has(descMatch[1])) errors.push(`Duplicate description in ${slug}`);
    descriptions.add(descMatch[1]);
  }

  if (!canonMatch || canonMatch[1] !== `https://onaymerkezi.org/${slug}`) {
    errors.push(`Invalid canonical in ${slug}: ${canonMatch?.[1]}`);
  } else {
    canonicals.add(canonMatch[1]);
  }

  if (h1Matches.length !== 1) {
    errors.push(`Expected 1 H1 in ${slug}, found ${h1Matches.length}`);
  } else {
    const h1Text = h1Matches[0].replace(/<[^>]+>/g, "");
    if (h1s.has(h1Text)) errors.push(`Duplicate H1 in ${slug}: ${h1Text}`);
    h1s.add(h1Text);
  }

  if (!jsonLdMatch) {
    errors.push(`Missing JSON-LD in ${slug}`);
  } else {
    try {
      const parsed = JSON.parse(jsonLdMatch[1]);
      const types = (parsed["@graph"] || []).map((x) => x["@type"]);
      for (const reqType of ["Organization", "WebSite", "BreadcrumbList", "Article", "FAQPage"]) {
        if (!types.includes(reqType)) errors.push(`Missing schema ${reqType} in ${slug}`);
      }
      const faqNode = parsed["@graph"].find((x) => x["@type"] === "FAQPage");
      if (!faqNode || !Array.isArray(faqNode.mainEntity) || faqNode.mainEntity.length < 5) {
        errors.push(`Expected >= 5 FAQs in ${slug}`);
      }
    } catch (err) {
      errors.push(`Invalid JSON-LD in ${slug}: ${err.message}`);
    }
  }
}

// Verify index.html
const indexHtml = fs.readFileSync(path.join(ROOT_DIR, "index.html"), "utf8");
for (const slug of EXPECTED_SLUGS) {
  if (!indexHtml.includes(`href="/${slug}"`)) {
    errors.push(`Missing menu link href="/${slug}" in index.html`);
  }
}
for (const pat of MOJIBAKE_PATTERNS) {
  if (pat.test(indexHtml)) {
    errors.push(`Mojibake pattern ${pat} found in index.html`);
  }
}

// Verify sitemap.xml (BOM-free XML, 101 URLs)
const sitemap = fs.readFileSync(path.join(PUBLIC_DIR, "sitemap.xml"), "utf8");
if (sitemap.charCodeAt(0) === 0xfeff) {
  errors.push("sitemap.xml must not start with UTF-8 BOM");
}
if (!sitemap.startsWith('<?xml version="1.0" encoding="UTF-8"?>')) {
  errors.push("sitemap.xml missing XML declaration");
}
if (!sitemap.includes("<loc>https://onaymerkezi.org/</loc>")) {
  errors.push("Missing homepage in sitemap.xml");
}
for (const slug of EXPECTED_SLUGS) {
  if (!sitemap.includes(`<loc>https://onaymerkezi.org/${slug}</loc>`)) {
    errors.push(`Missing ${slug} in sitemap.xml`);
  }
}
const locCount = (sitemap.match(/<loc>/g) || []).length;
if (locCount !== EXPECTED_SLUGS.length + 1) {
  errors.push(`Expected ${EXPECTED_SLUGS.length + 1} <loc> entries in sitemap.xml, found ${locCount}`);
}

// Verify robots.txt
const robots = fs.readFileSync(path.join(PUBLIC_DIR, "robots.txt"), "utf8");
if (!robots.includes("Sitemap: https://onaymerkezi.org/sitemap.xml")) {
  errors.push("Missing Sitemap line in robots.txt");
}

// Verify vercel.json
const vercelPath = path.join(ROOT_DIR, "vercel.json");
if (!fs.existsSync(vercelPath)) {
  errors.push("Missing vercel.json in project root");
} else {
  const vercelCfg = JSON.parse(fs.readFileSync(vercelPath, "utf8"));
  if (vercelCfg.outputDirectory !== "dist" || vercelCfg.cleanUrls !== true) {
    errors.push("vercel.json must specify outputDirectory: dist and cleanUrls: true");
  }
}

if (errors.length) {
  console.error("VERIFICATION FAILED:\n" + errors.join("\n"));
  process.exit(1);
}

console.log(
  `VERIFICATION PASSED: ${EXPECTED_SLUGS.length} pages, ${titles.size} unique titles, ${descriptions.size} unique descriptions, ${h1s.size} unique H1s, ${canonicals.size} unique canonicals, 0 mojibake.`
);
