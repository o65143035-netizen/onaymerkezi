import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { WHATSAPP_PAGES } from "./seo-data-whatsapp.mjs";
import { SANAL_PAGES } from "./seo-data-sanal.mjs";
import { SMS_PAGES } from "./seo-data-sms.mjs";
import { APPS_PAGES } from "./seo-data-apps.mjs";
import { PAYMENT_PAGES } from "./seo-data-payment.mjs";
import { COMP_OVERVIEW_PAGES } from "./seo-data-comp-overview.mjs";
import { COMP_GLOBAL_PAGES } from "./seo-data-comp-global.mjs";
import { COMP_ALTERNATIVES_PAGES } from "./seo-data-comp-alternatives.mjs";
import { COMP_PLATFORMS_PAGES } from "./seo-data-comp-platforms.mjs";
import { COMP_TECHNICAL_PAGES } from "./seo-data-comp-technical.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, "..");
const PUBLIC_DIR = path.join(ROOT_DIR, "public");
const SITE_URL = "https://onaymerkezi.org";
const TODAY = "2026-11-23";

const ALL_PAGES = [
  ...WHATSAPP_PAGES,
  ...SANAL_PAGES,
  ...SMS_PAGES,
  ...APPS_PAGES,
  ...PAYMENT_PAGES,
  ...COMP_OVERVIEW_PAGES,
  ...COMP_GLOBAL_PAGES,
  ...COMP_ALTERNATIVES_PAGES,
  ...COMP_PLATFORMS_PAGES,
  ...COMP_TECHNICAL_PAGES,
];

if (ALL_PAGES.length !== 100) {
  throw new Error(`Expected exactly 100 SEO pages, got ${ALL_PAGES.length}`);
}

const PAGE_BY_SLUG = new Map(ALL_PAGES.map((p) => [p.slug, p]));

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function buildTopMenuLinks(activeSlug = null) {
  return ALL_PAGES.map((p) => {
    const currentAttr = p.slug === activeSlug ? ' aria-current="page"' : "";
    return `        <a href="/${p.slug}"${currentAttr}>${escapeHtml(p.menuLabel)}</a>`;
  }).join("\n");
}

function buildSchemaJsonLd(page) {
  const pageUrl = `${SITE_URL}/${page.slug}`;
  const graph = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${SITE_URL}/#organization`,
        name: "Onay Merkezi",
        url: SITE_URL,
        email: "destek@onaymerkezi.org",
      },
      {
        "@type": "WebSite",
        "@id": `${SITE_URL}/#website`,
        name: "Onay Merkezi",
        url: SITE_URL,
        inLanguage: "tr-TR",
        publisher: { "@id": `${SITE_URL}/#organization` },
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: "Ana Sayfa",
            item: `${SITE_URL}/`,
          },
          {
            "@type": "ListItem",
            position: 2,
            name: page.category,
            item: pageUrl,
          },
          {
            "@type": "ListItem",
            position: 3,
            name: page.h1,
            item: pageUrl,
          },
        ],
      },
      {
        "@type": "Article",
        headline: page.h1,
        description: page.description,
        image: `${SITE_URL}${page.image}`,
        datePublished: TODAY,
        dateModified: TODAY,
        inLanguage: "tr-TR",
        mainEntityOfPage: {
          "@type": "WebPage",
          "@id": pageUrl,
        },
        author: {
          "@type": "Organization",
          name: "Onay Merkezi",
          url: SITE_URL,
        },
        publisher: { "@id": `${SITE_URL}/#organization` },
      },
      {
        "@type": "FAQPage",
        mainEntity: page.faqs.map((f) => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: {
            "@type": "Answer",
            text: f.a,
          },
        })),
      },
    ],
  };
  return JSON.stringify(graph, null, 2).replace(/<\/script>/gi, "<\\/script>");
}

function renderPageHtml(page) {
  const pageUrl = `${SITE_URL}/${page.slug}`;
  const topLinks = buildTopMenuLinks(page.slug);
  const relatedPages = (page.related || [])
    .map((slug) => PAGE_BY_SLUG.get(slug))
    .filter(Boolean);

  const sectionsHtml = page.sections
    .map((sec) => {
      const pHtml = (sec.paragraphs || [])
        .map((p) => `<p>${escapeHtml(p)}</p>`)
        .join("\n          ");
      const h3Html = sec.h3
        ? `<h3>${escapeHtml(sec.h3)}</h3>\n          ${(sec.h3Paragraphs || [])
            .map((p) => `<p>${escapeHtml(p)}</p>`)
            .join("\n          ")}`
        : "";
      const listHtml = sec.list
        ? `<ul class="om-seo-list">\n            ${sec.list
            .map((item) => `<li>${escapeHtml(item)}</li>`)
            .join("\n            ")}\n          </ul>`
        : "";
      return `<section class="om-seo-section" id="${escapeHtml(sec.id)}">
          <h2>${escapeHtml(sec.h2)}</h2>
          ${pHtml}
          ${h3Html}
          ${listHtml}
        </section>`;
    })
    .join("\n\n        ");

  const tableHtml = page.table
    ? `<section class="om-seo-section" id="referans-tablosu">
          <h2>${escapeHtml(page.table.title)}</h2>
          <div class="om-seo-table-wrap">
            <table class="om-seo-table">
              <thead>
                <tr>${page.table.headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr>
              </thead>
              <tbody>
                ${page.table.rows
                  .map(
                    (row) =>
                      `<tr>${row.map((cell) => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`
                  )
                  .join("\n                ")}
              </tbody>
            </table>
          </div>
          <p>Güncel tüm servis ve ülke stoklarını doğrudan <a href="/">Onay Merkezi ana sayfasındaki işlem panelinden</a> kontrol edebilirsiniz.</p>
        </section>`
    : "";

  const stepsHtml = page.steps
    ? `<section class="om-seo-section" id="adimlar">
          <h2>${escapeHtml(page.steps.title)}</h2>
          <div class="om-seo-steps">
            ${page.steps.items
              .map(
                (st) => `<div class="om-seo-step-card">
              <div class="om-seo-step-num">${escapeHtml(st.label)}</div>
              <div class="om-seo-step-title">${escapeHtml(st.title)}</div>
              <div class="om-seo-step-desc">${escapeHtml(st.desc)}</div>
            </div>`
              )
              .join("\n            ")}
          </div>
        </section>`
    : "";

  const faqHtml = `<section class="om-seo-section" id="sik-sorulan-sorular">
          <h2>Sık Sorulan Sorular</h2>
          <div class="om-seo-faq-list">
            ${page.faqs
              .map(
                (f, idx) => `<details class="om-seo-faq-item"${idx === 0 ? " open" : ""}>
              <summary>${escapeHtml(f.q)}</summary>
              <div class="om-seo-faq-answer">${escapeHtml(f.a)}</div>
            </details>`
              )
              .join("\n            ")}
          </div>
        </section>`;

  const relatedHtml = `<section class="om-seo-section" id="ilgili-rehberler">
          <h2>İlgili Rehberler ve Bağlantılar</h2>
          <p>Konuyla bağlantılı diğer rehberleri inceleyebilir veya doğrudan <a href="/">Onay Merkezi Ana Sayfa</a> üzerinden numara seçimine geçebilirsiniz.</p>
          <div class="om-seo-related-grid">
            ${relatedPages
              .map(
                (rp) => `<a class="om-seo-related-card" href="/${rp.slug}">
              <strong>${escapeHtml(rp.h1)}</strong>
              <span>${escapeHtml(rp.description)}</span>
            </a>`
              )
              .join("\n            ")}
          </div>
        </section>`;

  const sourcesHtml =
    Array.isArray(page.sources) && page.sources.length > 0
      ? `<section class="om-seo-section" id="kaynaklar">
          <h2>Araştırma Tarihi ve Doğrulanan Kaynaklar</h2>
          <p>Bu incelemede yer alan tüm platform bilgileri, yalnızca kamuya açık resmi sayfalar ve doğrulanabilir dokümantasyonlar üzerinden derlenmiştir.</p>
          <div class="om-seo-sources-box">
            <div class="om-seo-sources-meta">Araştırma Tarihi: ${escapeHtml(page.researchDate || "23 Kasım 2026")}</div>
            <ul class="om-seo-sources-list">
              ${page.sources
                .map(
                  (src) =>
                    `<li><a href="${escapeHtml(src.url)}" target="_blank" rel="noopener noreferrer nofollow">${escapeHtml(src.label)}</a> — ${escapeHtml(src.url)}</li>`
                )
                .join("\n              ")}
            </ul>
          </div>
        </section>`
      : "";

  const tocLinks = [
    ...page.sections.map((s) => `<a href="#${escapeHtml(s.id)}">${escapeHtml(s.h2)}</a>`),
    ...(page.table ? [`<a href="#referans-tablosu">${escapeHtml(page.table.title)}</a>`] : []),
    ...(page.steps ? [`<a href="#adimlar">${escapeHtml(page.steps.title)}</a>`] : []),
    `<a href="#sik-sorulan-sorular">Sık Sorulan Sorular</a>`,
    ...(sourcesHtml ? [`<a href="#kaynaklar">Araştırma Tarihi ve Kaynaklar</a>`] : []),
    `<a href="#ilgili-rehberler">İlgili Rehberler</a>`,
  ].join("\n            ");

  return `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(page.title)}</title>
  <meta name="description" content="${escapeHtml(page.description)}">
  <meta name="robots" content="index, follow, max-image-preview:large">
  <meta name="author" content="Onay Merkezi">
  <meta name="theme-color" content="#3b82f6">
  <link rel="canonical" href="${pageUrl}">
  <meta property="og:type" content="article">
  <meta property="og:title" content="${escapeHtml(page.title)}">
  <meta property="og:description" content="${escapeHtml(page.description)}">
  <meta property="og:url" content="${pageUrl}">
  <meta property="og:site_name" content="Onay Merkezi">
  <meta property="og:locale" content="tr_TR">
  <meta property="og:image" content="${SITE_URL}${page.image}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escapeHtml(page.title)}">
  <meta name="twitter:description" content="${escapeHtml(page.description)}">
  <meta name="twitter:image" content="${SITE_URL}${page.image}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/seo-pages.css">
  <script type="application/ld+json">
${buildSchemaJsonLd(page)}
  </script>
</head>
<body class="om-seo-body">
  <header class="om-seo-header">
    <div class="om-seo-header-top">
      <a href="/" class="om-seo-brand">Onay Merkezi</a>
      <div class="om-seo-header-actions">
        <a href="/" class="om-seo-btn-outline">Ana Sayfa</a>
        <a href="/#serviceList" class="om-seo-btn-primary">Numara Al</a>
      </div>
    </div>
    <div class="om-seo-topmenu-bar">
      <nav class="om-seo-topmenu" aria-label="Tüm Sanal Numara ve SMS Onay Rehberleri">
${topLinks}
      </nav>
    </div>
  </header>

  <main class="om-seo-main">
    <nav class="om-seo-breadcrumb" aria-label="İçerik Haritası">
      <a href="/">Ana Sayfa</a>
      <span class="om-seo-breadcrumb-sep" aria-hidden="true">/</span>
      <span>${escapeHtml(page.category)}</span>
      <span class="om-seo-breadcrumb-sep" aria-hidden="true">/</span>
      <span aria-current="page">${escapeHtml(page.menuLabel)}</span>
    </nav>

    <div class="om-seo-layout">
      <article class="om-seo-article">
        <div class="om-seo-hero">
          <div class="om-seo-kicker">
            <span>${escapeHtml(page.category)}</span>
            <span aria-hidden="true">·</span>
            <span>Onay Merkezi Rehberi</span>
          </div>
          <h1 class="om-seo-h1">${escapeHtml(page.h1)}</h1>
          <p class="om-seo-lead">${escapeHtml(page.lead)}</p>
          <div class="om-seo-hero-cta">
            <a href="/" class="om-seo-cta-btn">Ana Sayfadan Servis Seç</a>
            <a href="/sanal-numara-fiyatlari" class="om-seo-cta-secondary">Güncel Fiyatları İncele</a>
          </div>
          <figure class="om-seo-figure">
            <img src="${page.image}" alt="${escapeHtml(page.imageAlt)}" width="1280" height="720" loading="eager">
            <figcaption class="om-seo-figcaption">${escapeHtml(page.imageCaption)}</figcaption>
          </figure>
        </div>

        ${sectionsHtml}

        ${tableHtml}

        ${stepsHtml}

        ${faqHtml}

        ${sourcesHtml}

        ${relatedHtml}
      </article>

      <aside class="om-seo-sidebar" aria-label="Sayfa İçi Gezinme ve Hızlı Erişim">
        <div class="om-seo-sidecard">
          <div class="om-seo-sidecard-title">İçindekiler</div>
          <nav class="om-seo-toc-links">
            ${tocLinks}
          </nav>
        </div>

        <div class="om-seo-side-cta">
          <h3>Onay Merkezi Paneli</h3>
          <p>60'tan fazla ülkeden WhatsApp, Telegram, Instagram, Google ve daha fazlası için sanal numara seçin.</p>
          <a href="/">Hemen Ana Sayfaya Git</a>
        </div>

        <div class="om-seo-sidecard">
          <div class="om-seo-sidecard-title">Öne Çıkan Rehberler</div>
          <div class="om-seo-related-links">
            <a href="/whatsapp-sanal-numara">WhatsApp Sanal Numara</a>
            <a href="/sanal-numara-fiyatlari">Sanal Numara Fiyatları</a>
            <a href="/sms-kodu-gelmiyor">SMS Kodu Gelmiyor Çözümü</a>
            <a href="/sanal-numara-iban-ile-odeme">IBAN ile Bakiye Yükleme</a>
            <a href="/sms-onay-iade">İptal ve İade Süreci</a>
          </div>
        </div>
      </aside>
    </div>
  </main>

  <footer class="om-seo-footer">
    <div class="om-seo-footer-inner">
      <div class="om-seo-footer-top">
        <a href="/" class="om-seo-brand" style="color:#ffffff;">Onay Merkezi</a>
        <div class="om-seo-footer-links">
          <a href="/">Ana Sayfa</a>
          <a href="/whatsapp-sanal-numara">WhatsApp Sanal Numara</a>
          <a href="/sanal-numara-fiyatlari">Fiyatlar</a>
          <a href="/sanal-numara-sss">SSS</a>
          <a href="/onay-merkezi-guvenilir-mi">Onay Merkezi Nedir?</a>
          <a href="/sitemap.xml">Site Haritası</a>
        </div>
      </div>
      <div class="om-seo-footer-bottom">
        <span>© 2026 Onay Merkezi — Tüm hakları saklıdır.</span>
        <span>İletişim: destek@onaymerkezi.org</span>
      </div>
    </div>
  </footer>

  <script>
    (function () {
      var menu = document.querySelector(".om-seo-topmenu");
      if (!menu) return;
      var activeLink = menu.querySelector('a[aria-current="page"]');
      if (activeLink && activeLink.scrollIntoView) {
        activeLink.scrollIntoView({ block: "nearest", inline: "center" });
      }
      menu.addEventListener("wheel", function (e) {
        if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
          e.preventDefault();
          menu.scrollLeft += e.deltaY;
        }
      }, { passive: false });
    })();
  </script>
</body>
</html>
`;
}

// 1. Generate all 50 standalone HTML pages in public/<slug>/index.html
for (const page of ALL_PAGES) {
  const dir = path.join(PUBLIC_DIR, page.slug);
  fs.mkdirSync(dir, { recursive: true });
  const html = renderPageHtml(page);
  fs.writeFileSync(path.join(dir, "index.html"), html, "utf8");
}

// 2. Generate public/sitemap.xml (homepage + all 50 pages)
const sitemapUrls = [
  `  <url>
    <loc>${SITE_URL}/</loc>
    <lastmod>${TODAY}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`,
  ...ALL_PAGES.map(
    (p) => `  <url>
    <loc>${SITE_URL}/${p.slug}</loc>
    <lastmod>${TODAY}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`
  ),
];

const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${sitemapUrls.join("\n")}
</urlset>
`;
fs.writeFileSync(path.join(PUBLIC_DIR, "sitemap.xml"), sitemapXml, "utf8");

// 3. Generate public/robots.txt
const robotsTxt = `User-agent: *
Allow: /
Disallow: /downloads/

Sitemap: ${SITE_URL}/sitemap.xml
`;
fs.writeFileSync(path.join(PUBLIC_DIR, "robots.txt"), robotsTxt, "utf8");

// 4. Update root /index.html minimally from the exact original onaymerkezi.org source
const originalHtmlPath = path.join(
  PUBLIC_DIR,
  "assets",
  "aistudio",
  "Paste_November_23__2026_-_2_23PM_d5290ef7"
);
let indexHtml = fs.readFileSync(originalHtmlPath, "utf8");

const oldCssTarget =
  ".seo-top-menu{display:flex;gap:10px;overflow-x:auto;padding-bottom:10px;margin-bottom:5px;width:100%;justify-content:center;font-size:.85rem;font-weight:600;border-top:1px solid var(--border);padding-top:10px;}\n.seo-top-menu a{color:var(--primary);cursor:pointer;white-space:nowrap;text-decoration:none;background:var(--primary-light);padding:6px 12px;border-radius:8px;transition:all .2s;}\n.seo-top-menu a:hover{background:var(--primary);color:#fff;}";

const newCssTarget =
  ".seo-top-menu{display:flex;flex-wrap:nowrap;gap:8px;overflow-x:auto;overflow-y:hidden;padding:10px 4px 12px;margin-bottom:5px;width:100%;justify-content:flex-start;align-items:center;font-size:.82rem;font-weight:600;border-top:1px solid var(--border);-webkit-overflow-scrolling:touch;scrollbar-width:thin;scrollbar-color:#93c5fd #eff6ff;}\n.seo-top-menu::-webkit-scrollbar{height:6px;}\n.seo-top-menu::-webkit-scrollbar-track{background:#eff6ff;border-radius:999px;}\n.seo-top-menu::-webkit-scrollbar-thumb{background:#93c5fd;border-radius:999px;}\n.seo-top-menu a{color:var(--primary-dark);cursor:pointer;white-space:nowrap;flex-shrink:0;text-decoration:none;background:var(--primary-light);padding:6px 12px;border-radius:8px;transition:all .2s;}\n.seo-top-menu a:hover{background:var(--primary);color:#fff;}";

if (!indexHtml.includes(oldCssTarget)) {
  throw new Error("Could not locate original .seo-top-menu CSS block in source HTML");
}
indexHtml = indexHtml.replace(oldCssTarget, newCssTarget);

const oldMenuBlock = `    <!-- TIKLANABİLİR SEO MENÜSÜ -->
    <div class="seo-top-menu">
        <a onclick="showPage('rehber')">Sanal Numara Rehberi</a>
        <a onclick="showPage('sms-onay')">SMS Kodu Gelmezse</a>
        <a onclick="showPage('fiyatlar')">15 TL Fiyatlar</a>
        <a onclick="showPage('guvenlik')">Güvenli mi?</a>
    </div>`;

const newMenuBlock = `    <!-- TIKLANABİLİR SEO MENÜSÜ (100 SEO SAYFASI) -->
    <nav class="seo-top-menu" aria-label="SEO Rehber Menüsü">
${buildTopMenuLinks(null)}
    </nav>`;

if (!indexHtml.includes(oldMenuBlock)) {
  throw new Error("Could not locate original .seo-top-menu HTML block in source HTML");
}
indexHtml = indexHtml.replace(oldMenuBlock, newMenuBlock);

// Add subtle horizontal wheel scroll support for desktop users on .seo-top-menu without altering existing JS
const wheelHelper = `<script>
document.addEventListener('DOMContentLoaded',function(){var m=document.querySelector('.seo-top-menu');if(m){m.addEventListener('wheel',function(e){if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){e.preventDefault();m.scrollLeft+=e.deltaY;}},{passive:false});}});
</script>
</body>`;

if (!indexHtml.includes("</body>")) {
  throw new Error("Could not locate </body> in source HTML");
}
indexHtml = indexHtml.replace("</body>", wheelHelper);

fs.writeFileSync(path.join(ROOT_DIR, "index.html"), indexHtml, "utf8");

console.log(`Generated ${ALL_PAGES.length} SEO pages, sitemap.xml, robots.txt, and updated /index.html.`);
